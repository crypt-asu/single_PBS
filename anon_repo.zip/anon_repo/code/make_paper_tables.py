#!/usr/bin/env python3
"""Tables of the encrypted-layer and primitive results of the paper, generated from the raw JSON-lines logs.
   usage: python3 make_paper_tables.py --raw ../results/raw --out ../results"""
import argparse, json, os

ap = argparse.ArgumentParser()
ap.add_argument("--raw", default="../results/raw")
ap.add_argument("--out", default="../results")
a = ap.parse_args()

def jl(name): return [json.loads(l) for l in open(os.path.join(a.raw, name))]
def sci(x):
    m, e = ("%.2e" % x).split("e"); return "$%s{\\times}10^{%d}$" % (m, int(e))
def sec(ms): return "%.0f" % (ms / 1000)
def write(name, lines): open(os.path.join(a.out, name), "w").write("\n".join(lines) + "\n")

R = jl("raw_fhe_t48_layer.jsonl")
def pick(n, sm, ops): return [x for x in R if x["n"] == n and x["softmax"] == sm and x["ops"] == ops][0]

L = ["\\begin{tabular}{@{}rlrrrrrrr@{}}", "\\toprule",
     "$n$ & Softmax & \\#FBT & total & Softmax & LN$_1$+FFN+LN$_2$ & FBT time & max err.\\ out & MAE out \\\\", "\\midrule"]
for n in (4, 8):
    for sm, nm in (("cheb", "Cheb.+Newton"), ("fbt", "FBT")):
        r = pick(n, sm, "fbt")
        L.append("%d & %s & %d & %s & %s & %s & %s & %s & %s \\\\" % (n, nm, r["n_fbt"], sec(r["t_total_ms"]), sec(r["t_softmax_ms"]),
                 sec(r["t_ln1_ms"] + r["t_ffn_ms"] + r["t_ln2_ms"]), sec(r["t_fbt_ms"]), sci(r["err_out_max"]), sci(r["err_out_mae"])))
write("fhe_layer.tex", L + ["\\bottomrule", "\\end{tabular}"])

L = ["\\begin{tabular}{@{}rrrrrrrr@{}}", "\\toprule", "$n$ & rounds & \\#FBT & time (s) & share & $\\max|\\hat M-\\max|$ & $\\Omega_{\\rm cal}$ & outside range \\\\", "\\midrule"]
for n in (4, 8):
    r = pick(n, "fbt", "fbt")
    L.append("%d & %d & %d & %s & %.1f\\%% & %s & %.2f & %d \\\\" % (n, r["n_rounds"], r["n_fbt"], sec(r["t_tour_ms"]), 100 * r["t_tour_ms"] / r["t_total_ms"], sci(r["err_tour_max"]), r["omega_cal"], r["oow_tour"]))
write("fhe_layer_tour.tex", L + ["\\bottomrule", "\\end{tabular}"])

L = ["\\begin{tabular}{@{}rrrrrrrrr@{}}", "\\toprule", "$n$ & logits & row max & $P$ & $z_1$ & LN$_1$ & GELU & $z_2$ & out \\\\", "\\midrule"]
for n in (4, 8):
    r = pick(n, "fbt", "fbt")
    L.append("%d & %s \\\\" % (n, " & ".join(sci(r[k]) for k in ("err_logits_max", "err_tour_max", "err_P_max", "err_z1_max", "err_ln1_max", "err_gelu_max", "err_z2_max", "err_out_max"))))
write("fhe_layer_stage.tex", L + ["\\bottomrule", "\\end{tabular}"])

L = ["\\begin{tabular}{@{}rrrrrr@{}}", "\\toprule", "$n$ & $H$ & \\#FBT & levels used & max err.\\ $P$ & max err.\\ out \\\\", "\\midrule"]
for n in (4, 8):
    r = [x for x in R if x["n"] == n and x["ops"] == "oracle"][0]
    L.append("%d & %d & %d & %d & %s & %s \\\\" % (n, r["H"], r["n_fbt"], r["l_out"], sci(r["err_P_max"]), sci(r["err_out_max"])))
write("fhe_layer_oracle.tex", L + ["\\bottomrule", "\\end{tabular}"])

C = [x for x in jl("raw_fhe_t48_calib.jsonl") if x.get("probe") == "range"]
def g(x): return "%.4g" % x if x >= 1e-3 else sci(x)
L = ["\\begin{tabular}{@{}lccc@{}}", "\\toprule", "index $v$ & output & table value (clamped) & table value (wrapped) \\\\", "\\midrule"]
for r in C:
    if r["in"] in (-5.0, -20.0, 255.5, 256.0, 257.0, 276.0):
        L.append("$%s$ & %s & %s & %s \\\\" % (("%g" % r["in"]).replace("-", "-"), g(r["out"]), g(r["g_clamped"]), g(r["g_wrapped"])))
write("fhe_calibration.tex", L + ["\\bottomrule", "\\end{tabular}"])
print("tables written to", a.out)
