#!/usr/bin/env python3
"""
Plaintext emulation study (CPU, seconds).  Produces
  results/analytic_bounds.tex   rigorous worst-case interpolation bounds (pure math)
  results/emu_stage.tex         stage-wise standalone errors under idealised interpolants
  results/emu_e2e.tex           end-to-end softmax error vs. d under idealised interpolants
  results/emu_raw.json          everything, with seeds

This answers the Stage-4 questions of Review B *for idealised interpolants*;
the library's actual behaviour is measured by fhe/ (calibrate + bench).
"""
import argparse, json, os, sys
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from lut_models import (LUT, MODELS, exp_lut, inv_lut, exp_derivs, inv_derivs, interp_bound,
                        lut_softmax, exact_softmax)

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="../../results")
ap.add_argument("--seed", type=int, default=12345)
ap.add_argument("--rows", type=int, default=20000)
ap.add_argument("--p", type=int, default=256)
ap.add_argument("--omega", type=float, default=10.0)
ap.add_argument("--dims", type=int, nargs="+", default=[4, 8, 16, 32, 64, 128])
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
rng = np.random.default_rng(args.seed)
p, Om = args.p, args.omega
raw = {"seed": args.seed, "p": p, "Omega": Om, "rows": args.rows}


def sci(x):
    if x == 0:
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    return f"${m:.2f}{{\\times}}10^{{{e}}}$"


# ---------------------------------------------------------------- analytic bounds
# Two node spacings: full-range mapping (G=0, h = range/(p-1)) and the mapping used by the layer with G guard nodes
# at each end of the table (h = range/(p-1-2G)).  Every bound is proportional to h^r, so the G=8 entries equal the G=0
# entries multiplied by ((p-1)/(p-1-2G))^r.
GG = 8
hE = Om / (p - 1)
lines = [r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
         r" & \multicolumn{3}{c}{$G=0$} & \multicolumn{3}{c}{$G=8$} \\",
         r"\textbf{Stage / domain} & round & linear & Hermite-3 & round & linear & Hermite-3 \\", r"\midrule"]
MODS = ("round", "linear", "hermite3")
def both(rng, M):
    r0 = [interp_bound(m, rng / (p - 1), M) for m in MODS]
    r1 = [interp_bound(m, rng / (p - 1 - 2 * GG), M) for m in MODS]
    return r0, r1
r0, r1 = both(Om, exp_derivs(Om))
lines.append(r"$f_{\exp}$ on $[-\Omega,0]$ & " + " & ".join(sci(v) for v in r0 + r1) + r" \\")
raw["bound_exp"] = dict(zip(MODS, r0)); raw["bound_exp_guard"] = dict(zip(MODS, r1))
raw["bound_inv"] = {}; raw["bound_inv_guard"] = {}
for smin in (1.0, float(np.exp(-1))):
    for d in (16, 64, 128):
        M = inv_derivs(smin)
        r0, r1 = both(d - smin, M)
        lab = f"$f_{{\\mathrm{{inv}}}}$, $d{{=}}{d}$, $s_{{\\min}}{{=}}{'1' if smin == 1.0 else 'e^{-1}'}$"
        lines.append(lab + " & " + " & ".join(sci(v) for v in r0 + r1) + r" \\")
        raw["bound_inv"][f"d{d}_smin{smin:.3f}"] = dict(zip(MODS, r0))
        raw["bound_inv_guard"][f"d{d}_smin{smin:.3f}"] = dict(zip(MODS, r1))
lines += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/analytic_bounds.tex", "w").write("\n".join(lines) + "\n")

# ---------------------------------------------------------------- stage-wise
stage = {}
tabl = [r"\begin{tabular}{@{}llcccc@{}}", r"\toprule",
        r"\textbf{Stage} & \textbf{model} & \textbf{MAE} & \textbf{max err} & \textbf{bound} & \textbf{ratio} \\", r"\midrule"]
for model in ("round", "linear", "quad", "hermite3"):
    L = exp_lut(Om, p, model, "clamp")
    x = rng.uniform(-Om, 0, args.rows * 5)
    err = np.abs(L(x) - np.exp(x))
    b = interp_bound(model, hE, exp_derivs(Om)) if model != "quad" else interp_bound("quad", hE, exp_derivs(Om))
    stage[f"exp_{model}"] = dict(mae=err.mean(), max=err.max(), bound=b)
    tabl.append(f"$f_{{\\exp}}$ & {model} & {sci(err.mean())} & {sci(err.max())} & {sci(b)} & {err.max() / b:.2f} \\\\")
tabl.append(r"\midrule")
for d in (16, 128):
    for model in ("round", "linear", "hermite3"):
        smin = 1.0
        L = inv_lut(smin, float(d), p, model, "clamp")
        s = rng.uniform(smin, d, args.rows * 5)
        err = np.abs(L(s) - 1 / s)
        b = interp_bound(model, (d - smin) / (p - 1), inv_derivs(smin))
        stage[f"inv_d{d}_{model}"] = dict(mae=err.mean(), max=err.max(), bound=b)
        tabl.append(f"$f_{{\\mathrm{{inv}}}}$, $d{{=}}{d}$ & {model} & {sci(err.mean())} & {sci(err.max())} & {sci(b)} & {err.max() / b:.2f} \\\\")
tabl += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/emu_stage.tex", "w").write("\n".join(tabl) + "\n")
raw["stage"] = stage

# ---------------------------------------------------------------- end-to-end vs d
e2e = {}
tabl = [r"\begin{tabular}{@{}rcccc@{}}", r"\toprule",
        r"$d$ & MAE (linear) & max (linear) & MAE (Hermite-3) & max (Hermite-3) \\", r"\midrule"]
for d in args.dims:
    # rows whose logits fall inside the window of Assumption 1: spread < Omega, exact max known
    y = rng.normal(0, 1.5, size=(args.rows, d))
    y = np.clip(y, y.max(-1, keepdims=True) - Om, None)
    ystar = y.max(-1, keepdims=True)
    ref = exact_softmax(y)
    res = {}
    for model in ("linear", "hermite3"):
        a, _, _ = lut_softmax(y, ystar, d, Omega=Om, p=p, exp_model=model, inv_model=model, smin=1.0)
        err = np.abs(a - ref)
        res[model] = dict(mae=err.mean(), max=err.max())
    e2e[d] = res
    tabl.append(f"{d} & {sci(res['linear']['mae'])} & {sci(res['linear']['max'])} & "
                f"{sci(res['hermite3']['mae'])} & {sci(res['hermite3']['max'])} \\\\")
tabl += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/emu_e2e.tex", "w").write("\n".join(tabl) + "\n")
raw["e2e"] = e2e

# ---------------------------------------------------------------- out-of-window behaviour
oow = {}
d = 16
y = rng.normal(0, 1.5, size=(args.rows, d))
ystar = y.max(-1, keepdims=True)
for delta in (0.0, 1.0, 5.0, 12.0):               # over-estimate of the max by delta
    for mode in ("clamp", "wrap"):
        smin = float(np.exp(-delta)) if delta < 6 else float(np.exp(-6))
        a, _, S = lut_softmax(y, ystar + delta, d, Omega=Om, p=p, exp_model="hermite3",
                              inv_model="hermite3", smin=smin, mode=mode)
        err = np.abs(a - exact_softmax(y))
        oow[f"delta{delta}_{mode}"] = dict(mae=err.mean(), max=err.max())
raw["out_of_window"] = oow
json.dump(raw, open(f"{args.out}/emu_raw.json", "w"), indent=1, default=float)
print("wrote", args.out)
