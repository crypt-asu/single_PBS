"""
Idealised *plaintext* models of CKKS functional bootstrapping (FBT) look-up tables.

IMPORTANT: this module models what an FBT LUT *could* compute; it is NOT the
sec-CKKS library.  Which model matches the library is decided empirically by
fhe/calibrate_semantics (see code/README.md).  All numbers produced with this
module must be labelled "plaintext emulation" in the paper.

Works on numpy arrays and torch tensors (array-namespace shim `xp`).

Model of EvalFuncBootstrap(ct, f, p, k) on an input index v (real valued, because
the encrypted index is a real number carried in a CKKS slot):

  round    : v is rounded to the nearest integer node, output = f(node)
  linear   : piecewise-linear interpolation between integer nodes
  quad     : piecewise quadratic Lagrange interpolation (3 nodes)
  hermite3 : piecewise cubic Hermite (value + first derivative at both ends)

Index domain handling (mode):
  clamp : v is clipped to [0, p-1]
  wrap  : v is reduced modulo p (what a modular FBT does with an out-of-range
          input); the table is treated as p-periodic.
"""
import math
import numpy as np

MODELS = ("round", "linear", "quad", "hermite3")


def _is_torch(x):
    return type(x).__module__.startswith("torch")


class _NP:
    floor = staticmethod(np.floor)
    exp = staticmethod(np.exp)

    @staticmethod
    def clip(x, lo, hi):
        return np.clip(x, lo, hi)

    @staticmethod
    def mod(x, m):
        return np.mod(x, m)

    @staticmethod
    def to_int(x):
        return x.astype(np.int64)

    @staticmethod
    def asarray(x, like=None):
        return np.asarray(x, dtype=np.float64)


def _get_xp(x):
    if _is_torch(x):
        import torch

        class _T:
            floor = staticmethod(torch.floor)
            exp = staticmethod(torch.exp)

            @staticmethod
            def clip(x, lo, hi):
                return torch.clamp(x, lo, hi)

            @staticmethod
            def mod(x, m):
                return torch.remainder(x, m)

            @staticmethod
            def to_int(x):
                return x.long()

            @staticmethod
            def asarray(v, like=None):
                return torch.as_tensor(v, dtype=like.dtype, device=like.device)

        return _T
    return _NP


class LUT:
    """LUT of a smooth function g on [lo, hi] with p uniformly spaced nodes."""

    def __init__(self, g, dg, lo, hi, p, model="hermite3", mode="clamp"):
        assert model in MODELS and mode in ("clamp", "wrap")
        self.g, self.dg, self.lo, self.hi, self.p = g, dg, float(lo), float(hi), int(p)
        self.model, self.mode = model, mode
        self.h = (self.hi - self.lo) / (self.p - 1)

    # -- tables are rebuilt on the device/dtype of the input -----------------
    def _tables(self, like):
        xp = _get_xp(like)
        k = np.arange(self.p, dtype=np.float64)
        x = self.lo + k * self.h
        ys = self.g(x)
        dys = self.dg(x) * self.h  # derivative w.r.t. the *index*
        if xp is _NP:
            return ys, dys
        return xp.asarray(ys, like), xp.asarray(dys, like)

    def index(self, x):
        """real-valued LUT index of a point x of the function domain"""
        return (x - self.lo) / self.h

    def eval_index(self, v):
        xp = _get_xp(v)
        ys, dys = self._tables(v)
        p = self.p
        if self.mode == "clamp":
            v = xp.clip(v, 0.0, p - 1.0)
            node = lambda i: xp.to_int(xp.clip(i, 0, p - 1))
        else:
            v = xp.mod(v, p)
            node = lambda i: xp.to_int(xp.mod(i, p))
        if self.model == "round":
            return ys[node(xp.floor(v + 0.5))]
        i = xp.floor(v)
        t = v - i
        if self.model == "linear":
            return ys[node(i)] * (1 - t) + ys[node(i + 1)] * t
        if self.model == "quad":
            # nodes i0, i0+1, i0+2; in clamp mode the last cell uses nodes p-3..p-1 (t in [1,2])
            i = xp.clip(i, 0, p - 3)       # same edge handling in both modes (wrap only reduces v mod p)
            t = v - i
            y0, y1, y2 = ys[node(i)], ys[node(i + 1)], ys[node(i + 2)]
            l0 = (t - 1) * (t - 2) / 2
            l1 = -t * (t - 2)
            l2 = t * (t - 1) / 2
            return y0 * l0 + y1 * l1 + y2 * l2
        # hermite3
        y0, y1 = ys[node(i)], ys[node(i + 1)]
        m0, m1 = dys[node(i)], dys[node(i + 1)]
        t2, t3 = t * t, t * t * t
        return (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * m1

    def __call__(self, x):
        return self.eval_index(self.index(x))


# ---------------------------------------------------------------------------
# rigorous worst-case bounds for the *interpolation* error (inputs on-grid-range,
# exact arithmetic).  M_m = sup |g^{(m)}| on the table domain.
#   round    : (h/2) M1
#   linear   : h^2 M2 / 8
#   quad     : h^3 M3 / 12         (m=2: M_{m+1} h^{m+1} / (4(m+1)))
#   hermite3 : h^4 M4 / 384
# ---------------------------------------------------------------------------
def interp_bound(model, h, M):
    if model == "round":
        return 0.5 * h * M[1]
    if model == "linear":
        return h ** 2 * M[2] / 8.0
    if model == "quad":
        return h ** 3 * M[3] / 12.0
    if model == "hermite3":
        return h ** 4 * M[4] / 384.0
    raise ValueError(model)


def exp_derivs(Omega):
    """sup |d^m/dx^m exp| on [-Omega, 0]  (equal to 1 for all m)"""
    return {m: 1.0 for m in range(1, 5)}


def inv_derivs(smin):
    """sup |d^m/ds^m (1/s)| on [smin, inf) = m! / smin^(m+1)"""
    return {m: math.factorial(m) / smin ** (m + 1) for m in range(1, 5)}


def exp_lut(Omega, p, model, mode):
    # table over x = y - y* in [-Omega, 0]
    return LUT(np.exp, np.exp, -Omega, 0.0, p, model, mode)


def inv_lut(smin, smax, p, model, mode):
    return LUT(lambda s: 1.0 / s, lambda s: -1.0 / s ** 2, smin, smax, p, model, mode)


class EmpLUT:
    """Table whose response between the nodes is the MEASURED response curve of EvalFuncBootstrap
    (fhe/bench_softmax --mode curve): G equidistant samples of y(v), v in [0,p), p-periodic (the primitive is modular).
    Linear interpolation between samples; noise-free (it is the mean response of one measurement run)."""

    def __init__(self, x, y, p, lo, hi, scale_in):
        self.x = np.asarray(x, float); self.y = np.asarray(y, float)
        self.G, self.p, self.lo, self.hi = len(self.y), int(p), float(lo), float(hi)
        self.index = scale_in                     # real-domain value -> table index

    def eval_index(self, v):
        xp = _get_xp(v)
        ys = self.y if xp is _NP else xp.asarray(self.y, v)
        pos = xp.mod(v, float(self.p)) * (self.G / float(self.p))
        i = xp.floor(pos)
        t = pos - i
        i0 = xp.to_int(xp.mod(i, float(self.G)))
        i1 = xp.to_int(xp.mod(i + 1, float(self.G)))
        return ys[i0] * (1 - t) + ys[i1] * t

    def __call__(self, x):
        return self.eval_index(self.index(x))


def load_curves(path, order, inv_d):
    """read exp (given Hermite order) and inv (given d) curves from a raw_fhe*.jsonl produced by bench_softmax"""
    import json
    exp = inv = None
    for line in open(path):
        r = json.loads(line)
        if r.get("mode") != "curve":
            continue
        if r["func"] == "exp" and r["hermite_order"] == order:
            exp = r
        if r["func"] == "inv" and r["d"] == inv_d:
            inv = r
    if exp is None or inv is None:
        raise SystemExit(f"curve records not found (order={order}, d={inv_d}) in {path}")
    return exp, inv


def lut_softmax(y, ystar, d, *, Omega=10.0, p=256, exp_model="hermite3", inv_model="hermite3",
                smin=1.0, mode="clamp", newton=0, mask=None, exp_curve=None, inv_curve=None, smax=None):
    """
    Emulation of Algorithm 1 (Stages 0-5) on logits `y` with last axis = d.
      ystar : plaintext logit upper bound (scalar or broadcastable)
      smin  : lower end of the reciprocal table domain; MUST satisfy
              smin <= sum_j exp(y_j - ystar)  (see Assumption 2 in the paper)
      mask  : optional boolean array, True = position participates (padding positions
              are zeroed after the exp stage, as an encrypted 0/1 plaintext mask would).
      newton: number of Newton-Raphson refinement steps r <- r(2 - S r) after the
              reciprocal LUT (+2 outer levels per step).
    Returns (softmax_approx, e_hat, S_hat).
    """
    xp = _get_xp(y)
    smax = float(d) if smax is None else float(smax)
    h = Omega / (p - 1)
    if exp_model == "empirical":
        L_exp = EmpLUT(exp_curve["x"], exp_curve["y"], p, -Omega, 0.0, lambda x: (x + Omega) / h)
    else:
        L_exp = exp_lut(Omega, p, exp_model, mode)
    if inv_model == "empirical":
        a = (p - 1) / (smax - smin)
        L_inv = EmpLUT(inv_curve["x"], inv_curve["y"], p, smin, smax, lambda s: (s - smin) * a)
    else:
        L_inv = inv_lut(smin, smax, p, inv_model, mode)
    x = y - ystar  # in [-Omega, 0] under Assumption 1
    e = L_exp(x)
    if mask is not None:
        e = e * mask
    S = e.sum(-1, keepdims=True) if xp is _NP else e.sum(-1, keepdim=True)
    r = L_inv(S)
    for _ in range(newton):
        r = r * (2.0 - S * r)
    return e * r, e, S


def exact_softmax(y, mask=None):
    xp = _get_xp(y)
    if xp is _NP:
        z = np.exp(y - y.max(-1, keepdims=True))
    else:
        z = (y - y.max(-1, keepdim=True).values).exp()
    if mask is not None:
        z = z * mask
    return z / (z.sum(-1, keepdims=True) if xp is _NP else z.sum(-1, keepdim=True))
