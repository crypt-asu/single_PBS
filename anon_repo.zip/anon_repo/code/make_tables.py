#!/usr/bin/env python3
"""
Single script that regenerates every FHE table of the paper from raw JSON-lines logs
(Review B: "regenerate every table from a single script in one run").

  python make_tables.py --raw ../results/raw_fhe.jsonl --out ../results

Writes  fhe_calibration.tex fhe_stage.tex fhe_e2e.tex fhe_breakdown.tex fhe_linear.tex
        fhe_keys.tex fhe_amortised.tex values.tex  (values.tex defines \\V@<key> macros used by the paper)
Nothing is estimated: a cell is "--" if the corresponding raw records do not exist.
"""
import argparse, json, math, os, collections
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("--raw", nargs="+", default=["../results/raw_fhe.jsonl"], help="one or more raw jsonl files (concatenated)")
ap.add_argument("--out", default="../results")
ap.add_argument("--l_outer", type=float, default=0.0,
                help="usable levels after one bootstrap (read from the params dump if 0)")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
recs = [json.loads(l) for f in args.raw if os.path.exists(f) for l in open(f)]
T975 = {1: 12.71, 2: 4.30, 3: 3.18, 4: 2.78, 5: 2.57, 9: 2.26, 19: 2.09, 29: 2.045, 49: 2.01}


def tcrit(n):
    ks = sorted(T975)
    for k in ks:
        if n - 1 <= k:
            return T975[k]
    return 1.96


def ms(vals):
    v = np.asarray(vals, float)
    if len(v) == 0:
        return "--"
    if len(v) < 2:
        return f"{v.mean():.1f}"
    ci = tcrit(len(v)) * v.std(ddof=1) / math.sqrt(len(v))
    return f"{v.mean():.1f}$\\pm${ci:.1f}"


def sci(x):
    if x is None or (isinstance(x, float) and (math.isnan(x))):
        return "--"
    if x == 0:
        return "0"
    e = int(math.floor(math.log10(abs(x))))
    return f"${x / 10 ** e:.2f}{{\\times}}10^{{{e}}}$"


def sel(mode, **kw):
    return [r for r in recs if r.get("mode") == mode and all(r.get(k) == v for k, v in kw.items())]


def write(name, body):
    open(os.path.join(args.out, name), "w").write(body)


values = {}
dims = sorted({r["d"] for r in recs if r.get("mode") == "e2e" and "d" in r})

# ---- ablation: constant folding (no extra level) vs explicit scaling; Newton steps of the leveled baseline
rows = [r"\begin{tabular}{@{}rrrrrrr@{}}", r"\toprule",
        r"$d$ & folded ms & folded lev. & explicit ms & explicit lev. & Cheb.\ Newton 4 (ms/lev.) & Newton 2 (ms/lev.) \\", r"\midrule"]
for d in dims:
    fo, ex = sel("e2e", d=d, scaling="folded"), sel("e2e", d=d, scaling="explicit")
    c4, c2 = sel("cheb", d=d, newton=4), sel("cheb", d=d, newton=2)
    lv = lambda rs, k: int(round(np.mean([r[k] for r in rs]))) if rs else "--"
    cl = lambda rs: f"{ms([r['t_total_ms'] for r in rs])} / {int(round(np.mean([r['levels_out'] - r['levels_in'] for r in rs])))}" if rs else "--"
    rows.append(f"{d} & {ms([r['t_total_ms'] for r in fo]) if fo else '--'} & {lv(fo, 'outer_levels')} & "
                f"{ms([r['t_total_ms'] for r in ex]) if ex else '--'} & {lv(ex, 'outer_levels')} & {cl(c4)} & {cl(c2)} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_ablation.tex", "\n".join(rows) + "\n")

# ---- end-to-end FBT vs leveled baseline, one run, same harness
rows = [r"\begin{tabular}{@{}r|rrrr|rrrr|r@{}}", r"\toprule",
        r" & \multicolumn{4}{c|}{\textbf{Leveled (Cheb.+Newton)}} & \multicolumn{4}{c|}{\textbf{FBT (this work)}} & \\",
        r"$d$ & ms & lev. & MAE & max & ms & lev. & MAE & max & speed-up \\", r"\midrule"]
for d in dims:
    f = sel("e2e", d=d, scaling="folded")
    b = sel("cheb", d=d, newton=4)
    if not f:
        continue
    fm = np.mean([r["t_total_ms"] for r in f])
    bm = np.mean([r["t_total_ms"] for r in b]) if b else None
    lev = lambda rs: (int(round(np.mean([r["outer_levels"] if "outer_levels" in r else r["levels_out"] - r["levels_in"] for r in rs]))) if rs else "--")
    mae = lambda rs: np.mean([r["mae"] for r in rs]) if rs else None
    mx = lambda rs: np.max([r["max"] for r in rs]) if rs else None
    sp = f"{(1 - fm / bm) * 100:.1f}\\%" if bm else "--"
    rows.append(f"{d} & {ms([r['t_total_ms'] for r in b]) if b else '--'} & {lev(b)} & {sci(mae(b))} & {sci(mx(b))} & "
                f"{ms([r['t_total_ms'] for r in f])} & {lev(f)} & {sci(mae(f))} & {sci(mx(f))} & {sp} \\\\")
    values[f"fbt_ms_d{d}"] = f"{fm:.1f}"
    if bm:
        values[f"cheb_ms_d{d}"] = f"{bm:.1f}"
        values[f"speedup_d{d}"] = sp
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_e2e.tex", "\n".join(rows) + "\n")

# ---- component-level breakdown (Review A)
rows = [r"\begin{tabular}{@{}rrrrrrr@{}}", r"\toprule",
        r"$d$ & exp FBT & slot-sum & pre-map & inv FBT & final mult & total \\", r"\midrule"]
for d in dims:
    f = sel("e2e", d=d, scaling="folded")
    if f:
        g = lambda k: ms([r[k] for r in f])
        rows.append(f"{d} & {g('t_exp_fbt_ms')} & {g('t_slotsum_ms')} & {g('t_pre_ms')} & {g('t_inv_fbt_ms')} & {g('t_final_mul_ms')} & {g('t_total_ms')} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_breakdown.tex", "\n".join(rows) + "\n")

# ---- stage-wise standalone error
rows = [r"\begin{tabular}{@{}llcc@{}}", r"\toprule", r"\textbf{Stage} & $d$ & MAE & max \\", r"\midrule"]
st = sel("stage", stage="exp")
if st:
    rows.append(f"$f_{{\\exp}}$ & -- & {sci(np.mean([r['mae'] for r in st]))} & {sci(np.max([r['max'] for r in st]))} \\\\")
for d in sorted({r['d'] for r in sel('stage', stage='inv')}):
    s = sel("stage", stage="inv", d=d)
    rows.append(f"$f_{{\\mathrm{{inv}}}}$ & {d} & {sci(np.mean([r['mae'] for r in s]))} & {sci(np.max([r['max'] for r in s]))} \\\\")
    values[f"inv_mae_d{d}"] = sci(np.mean([r['mae'] for r in s]))
    values[f"inv_max_d{d}"] = sci(np.max([r['max'] for r in s]))
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_stage.tex", "\n".join(rows) + "\n")

# ---- calibration summary
cal = sel("calibrate")
rows = [r"\begin{tabular}{@{}lc@{}}", r"\toprule", r"\textbf{probe} & \textbf{result} \\", r"\midrule"]
mod = [r for r in cal if r.get("probe") == "model"]
if mod:
    for k in ("round", "linear", "hermite3"):
        rows.append(f"MAE vs.\\ `{k}' model & {sci(np.mean([r['mae_' + k] for r in mod]))} \\\\")
    best = min(("round", "linear", "hermite3"), key=lambda k: np.mean([r['mae_' + k] for r in mod]))
    values["lib_model"] = best
for r in [x for x in cal if x.get("probe") == "range"]:
    rows.append(f"input {r['in']:.1f} $\\to$ output {r['out']:.4g} (clamped {r['g_clamped']:.4g}, wrapped {r['g_wrapped']:.4g}) & \\\\")
for r in [x for x in cal if x.get("probe") == "imag"][:1]:
    rows.append(f"imaginary part of raw output: max $|\\mathrm{{Im}}-g(0)|$ = {sci(r['imag_dev_from_g0'])} ($g(0)$ = {r['g0']:.4g}); real part vs.\\ $g$: {sci(r['real_dev_from_g'])} & \\\\")
for r in [x for x in cal if x.get("probe") == "imagprod"][:1]:
    rows.append(f"product of two outputs vs.\\ $g^2$: raw {sci(r['err_raw_product'])}, with conjugation {sci(r['err_conj_product'])} & \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_calibration.tex", "\n".join(rows) + "\n")

# ---- linear (hoisted vs unhoisted)
rows = [r"\begin{tabular}{@{}rrr@{}}", r"\toprule", r"$d$ & unhoisted (ms) & hoisted (ms) \\", r"\midrule"]
for d in sorted({r["d"] for r in sel("linear")}):
    u = [r["t_matvec_ms"] for r in sel("linear", d=d, hoisted=0)]
    h = [r["t_matvec_ms"] for r in sel("linear", d=d, hoisted=1)]
    rows.append(f"{d} & {ms(u)} & {ms(h)} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_linear.tex", "\n".join(rows) + "\n")

# ---- keys / memory
k = sel("keys")
rows = [r"\begin{tabular}{@{}lr@{}}", r"\toprule", r"\textbf{object} & \textbf{size (MiB)} \\", r"\midrule"]
if k:
    rows.append(f"relinearisation key & {k[-1]['evalmult_key_bytes'] / 2**20:.1f} \\\\")
    rows.append(f"rotation (automorphism) keys & {k[-1]['automorphism_keys_bytes'] / 2**20:.1f} \\\\")
    rows.append(f"peak RSS of the process & {k[-1]['peak_rss_kb'] / 1024:.0f} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_keys.tex", "\n".join(rows) + "\n")

# ---- amortised-bootstrapping cost model   T_leveled + (levels / L_outer) * T_boot   vs   T_fbt
b = sel("boot")
rows = [r"\begin{tabular}{@{}rrrr@{}}", r"\toprule", r"$d$ & leveled alone & leveled + amortised boot. & FBT \\", r"\midrule"]
if b and args.l_outer <= 0 and (b[0].get("params") or {}).get("depth") is not None:
    args.l_outer = float(b[0]["params"]["depth"] - np.mean([r["levels_after"] for r in b]))   # usable levels after one FBT output
if b and args.l_outer > 0:
    tboot = np.mean([r["t_fbt_identity_ms"] for r in b])
    for d in dims:
        f, c = sel("e2e", d=d, scaling="folded"), sel("cheb", d=d, newton=4)
        if f and c:
            lev = np.mean([r["levels_out"] - r["levels_in"] for r in c])  # leveled baseline starts at level 0
            tl = np.mean([r["t_total_ms"] for r in c])
            rows.append(f"{d} & {tl:.1f} & {tl + lev / args.l_outer * tboot:.1f} & {np.mean([r['t_total_ms'] for r in f]):.1f} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_amortised.tex", "\n".join(rows) + "\n")

# ---- curve: measured response of EvalFuncBootstrap between and at the integer nodes, and near the wrap boundary
cv = sel("curve")
fun = {"exp": lambda v, p, Om: np.exp(-Om + v * Om / (p - 1)), "sin": lambda v, p, Om: np.sin(2 * np.pi * v / p),
       "id": lambda v, p, Om: v}
rows = [r"\begin{tabular}{@{}lcccc@{}}", r"\toprule",
        r"\textbf{table} (Hermite ord.) & \textbf{at nodes} & \textbf{mid-cell} & \textbf{wrap zone (8 nodes)} & \textbf{amplitude} \\", r"\midrule"]
for r in cv:
    p, Om = r["p"], r["Omega"]
    x, y = np.array(r["x"]), np.array(r["y"])
    if r["func"] == "id":
        continue
    if r["func"] == "inv":                                   # explicit form 1/(smin + v (d-smin)/(p-1))
        sm, dd = r["smin"], r["d"]
        gf = lambda v: 1.0 / (sm + v * (dd - sm) / (p - 1))
        g = gf(x)
        label = f"$f_{{\\mathrm{{inv}}}}$, $d={dd}$, $p={p}$ ({r['hermite_order']})"
        amp = np.ptp(gf(np.arange(p)))
    else:
        g = fun[r["func"]](x, p, Om)
        label = f"$f_{{\\mathrm{{{r['func']}}}}}$, $p={p}$ ({r['hermite_order']})"
        amp = np.ptp(fun[r["func"]](np.arange(p), p, Om))
    err = np.abs(g - y)
    node = np.abs(x - np.round(x)) < 1e-9
    frac = np.abs(x - np.round(x))
    zone = 8 if p >= 64 else max(p // 4, 1)          # 'wrap zone' width in nodes (8 for the production table sizes)
    inner = (x > zone) & (x < p - zone)
    exploded = (not np.all(np.isfinite(y))) or np.abs(y).max() > 1e6 * max(amp, 1)
    cell = lambda m: "diverged" if exploded else (sci(float(err[m].max())) if m.any() else "--")
    rows.append(f"{label} & {cell(node)} & {cell(inner & (frac > 0.4))} & "
                f"{cell(~inner)} & {amp:.3g} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_curve.tex", "\n".join(rows) + "\n")

# ---- attention head (QKV projection, QK^T, Softmax, PV) -- FBT vs leveled, same harness
at = sel("attn")
rows = [r"\begin{tabular}{@{}rlrrrrrrrr@{}}", r"\toprule",
        r"$n$ & Softmax & total & proj. & $QK^\top$ & Softmax & $PV$ & share & MAE & max \\", r"\midrule"]
for n in sorted({r["n"] for r in at}):
    for sm in ("cheb", "fbt"):
        s = sel("attn", n=n, softmax=sm)
        if not s:
            continue
        g = lambda k: np.mean([r[k] for r in s])
        rows.append(f"{n} & {'Cheb.+Newton' if sm == 'cheb' else 'FBT'} & {ms([r['t_total_ms'] for r in s])} & {g('t_proj_ms'):.0f} & "
                    f"{g('t_logits_ms'):.0f} & {g('t_softmax_ms'):.0f} & {g('t_pv_ms'):.0f} & "
                    f"{100 * g('t_softmax_ms') / g('t_total_ms'):.1f}\\% & {sci(g('mae'))} & {sci(max(r['max'] for r in s))} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_attn.tex", "\n".join(rows) + "\n")


# ---- complete encoder layer (multi-head attention, Wo, residual, LayerNorm, FFN+GELU, LayerNorm): FBT vs leveled Softmax
ly = [r for r in sel("layer") if r.get("ops") == "fbt"]
rows = [r"\begin{tabular}{@{}rlrrrrrrr@{}}", r"\toprule",
        r"$n$ & Softmax & \#FBT & total & attention & LN$_1$+FFN+LN$_2$ & FBT time & max err.\ out & MAE out \\", r"\midrule"]
for n in sorted({r["n"] for r in ly}):
    for sm in ("cheb", "fbt"):
        s = [r for r in ly if r["n"] == n and r["softmax"] == sm]
        if not s:
            continue
        g = lambda k: np.mean([r[k] for r in s])
        att = g("t_proj_ms") + g("t_logits_ms") + g("t_softmax_ms") + g("t_pv_ms") + g("t_attnout_ms")
        rest = g("t_ln1_ms") + g("t_ffn_ms") + g("t_ln2_ms")
        rows.append(f"{n} & {'Cheb.+Newton' if sm == 'cheb' else 'FBT'} & {int(s[0]['n_fbt'])} & {ms([r['t_total_ms'] for r in s])} & "
                    f"{att:.0f} & {rest:.0f} & {g('t_fbt_ms'):.0f} & {sci(max(r['err_out_max'] for r in s))} & {sci(g('err_out_mae'))} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_layer.tex", "\n".join(rows) + "\n")

# per-stage error of the encrypted layer (FBT Softmax), against the exact plaintext layer, and calibrated-domain statistics
rows = [r"\begin{tabular}{@{}rrrrrrrrrrr@{}}", r"\toprule",
        r"$n$ & logits & row max & $P$ & $z_1$ & LN$_1$ & pre-GELU & GELU & $z_2$ & out & out-of-domain \\", r"\midrule"]
for n in sorted({r["n"] for r in ly}):
    s = [r for r in ly if r["n"] == n and r["softmax"] == "fbt"]
    if not s:
        continue
    mx = lambda k: sci(max(r[k] for r in s))
    oow = sum(r["oow_logits"] + r["oow_sum"] + r["oow_var1"] + r["oow_var2"] + r["oow_pre"] + r.get("oow_tour", 0) for r in s)
    tmx = sci(max(r["err_tour_max"] for r in s)) if all("err_tour_max" in r and r.get("maxmode") == "tour" for r in s) else "--"
    rows.append(f"{n} & {mx('err_logits_max')} & {tmx} & {mx('err_P_max')} & {mx('err_z1_max')} & {mx('err_ln1_max')} & {mx('err_pre_max')} & "
                f"{mx('err_gelu_max')} & {mx('err_z2_max')} & {mx('err_out_max')} & {oow} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_layer_stage.tex", "\n".join(rows) + "\n")

# tournament row maximum: cost and accuracy (FBT Softmax of the layer)
tr = [r for r in ly if r["softmax"] == "fbt" and r.get("maxmode") == "tour"]
rows = [r"\begin{tabular}{@{}rrrrrrrr@{}}", r"\toprule",
        r"$n$ & rounds & \#FBT & tournament & share of layer & $\max|\hat M-\max|$ & $\Omega_{\rm cal}$ & out-of-domain (tournament) \\", r"\midrule"]
for n in sorted({r["n"] for r in tr}):
    sx = [r for r in tr if r["n"] == n]
    g = lambda k: np.mean([r[k] for r in sx])
    rows.append(f"{n} & {int(sx[0]['n_rounds'])} & {int(sx[0]['n_fbt'])} & {ms([r['t_tour_ms'] for r in sx])} & "
                f"{100 * g('t_tour_ms') / g('t_total_ms'):.1f}\\% & {sci(max(r['err_tour_max'] for r in sx))} & {sx[0]['omega_cal']:.3g} & {sum(r['oow_tour'] for r in sx)} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_layer_tour.tex", "\n".join(rows) + "\n")

# plumbing check (test-only oracle): the same code with every FBT replaced by decrypt -> exact f -> re-encrypt
orc = [r for r in sel("layer") if r.get("ops") == "oracle"]
rows = [r"\begin{tabular}{@{}rrrrr@{}}", r"\toprule", r"$n$ & $H$ & levels used & max err.\ $P$ & max err.\ out \\", r"\midrule"]
for n in sorted({r["n"] for r in orc}):
    s = [r for r in orc if r["n"] == n]
    rows.append(f"{n} & {s[0]['H']} & {max(r['max_level'] for r in s)} & {sci(max(r['err_P_max'] for r in s))} & {sci(max(r['err_out_max'] for r in s))} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
write("fhe_layer_oracle.tex", "\n".join(rows) + "\n")

_ly = [r for r in recs if r.get("mode") == "layer"]
if _ly:
    values["ncal"] = str(int(_ly[0]["ncal"]))
if recs:
    r0 = recs[0]
    values["cpu"] = r0.get("cpu", "n/a")
    values["threads"] = str(r0.get("threads", "n/a"))
    pr = r0.get("params") or {}
    for k in ("ringDim", "logQ", "secLevel", "depth"):
        if k in pr:
            values[k] = str(pr[k])
esc = lambda v: str(v).replace("_", "\\_") if not str(v).startswith("$") else str(v)
write("values.tex", "".join(f"\\expandafter\\gdef\\csname V@{k}\\endcsname{{{esc(v)}}}\n" for k, v in values.items()))
print("tables written to", args.out, "from", len(recs), "records")
