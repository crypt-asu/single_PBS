// ctx_setup.h  --  the ONE place where the cryptographic context is created (implemented in ctx_setup_user.cpp).
//   The same make_ctx() is used by ALL benchmarks (FBT pipeline and Chebyshev baseline), so both run with an
//   identical ring dimension, modulus chain, key-switching technique, thread configuration and key material.
#pragma once
#include "openfhe.h"
#include <cstdint>
#include <map>
#include <memory>
#include <string>

using namespace lbcrypto;
using CT = Ciphertext<DCRTPoly>;

struct Ctx {
  CryptoContext<DCRTPoly> cc;
  KeyPair<DCRTPoly> kp;
  uint32_t slots;        // number of slots the ciphertexts are packed with
  uint32_t p;            // plaintext modulus handed to EvalFuncBootstrap (LUT size)
  uint32_t order;        // Hermite order handed to EvalFuncBootstrap
  uint32_t ringDim;
  std::string paramsJson;  // human readable dump of every parameter, logged with every run
  uint32_t depth;        // total multiplicative depth of the chain
  uint32_t inLevel;      // level (limbs consumed) at which fresh inputs for the FIRST FBT are encrypted
  std::shared_ptr<std::map<usint, EvalKey<DCRTPoly>>> conjKey;  // automorphism key of complex conjugation (index M-1)
};

// Process-wide configuration set from the CLI of bench_softmax (see ctx_setup_user.cpp)
extern uint32_t g_ringDim;      // 0 => let OpenFHE pick the smallest ring dim meeting HEStd_128_classic
extern bool     g_insecure;     // true => HEStd_NotSet (functional tests ONLY, never report timings)
extern uint32_t g_lb0, g_lb1;   // level budget (CtS, StC)
extern uint32_t g_extraDepth;   // levels reserved for the user pipeline between/after FBT calls

// numSlots : d for sparse packing (one row per ciphertext), N/2 for batched packing
// rotIdx   : rotation indices needed by the pipeline (positive and negative)
Ctx make_ctx(uint32_t numSlots, uint32_t p, uint32_t order, const std::vector<int32_t>& rotIdx);
