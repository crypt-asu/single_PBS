// ctx_setup_user.cpp -- builds the sec-CKKS context.  Follows the fork's own example
// src/pke/examples/ckks-functional-bootstrapping.cpp (FIXEDMANUAL scaling, SPARSE_TERNARY secret,
// HYBRID key switching: these three are REQUIRED by EvalFuncBootstrap, it throws otherwise).
#include "ctx_setup.h"
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

uint32_t g_ringDim = 0;
bool g_insecure = false;
uint32_t g_lb0 = 4, g_lb1 = 2;
uint32_t g_extraDepth = 12;

static long rss_mb() {
  std::ifstream f("/proc/self/status"); std::string l;
  while (std::getline(f, l)) if (l.rfind("VmHWM:", 0) == 0) return std::stol(l.substr(6)) / 1024;
  return -1;
}
#define PROG(msg) (std::cerr << "[ctx] " << msg << "  (peak RSS " << rss_mb() << " MB)" << std::endl)

Ctx make_ctx(uint32_t numSlots, uint32_t p, uint32_t order, const std::vector<int32_t>& rotIdx) {
  uint32_t bits = (uint32_t)std::lround(std::log2((double)p));
  if ((1u << bits) != p || bits < 1 || bits > 8)
    throw std::runtime_error("p must be a power of two, 2 <= p <= 256 (sec-CKKS supports up to 8 bits)");

  CCParams<CryptoContextCKKSRNS> parameters;
  parameters.SetSecretKeyDist(SPARSE_TERNARY);
  if (g_insecure) {
    parameters.SetSecurityLevel(HEStd_NotSet);
    parameters.SetRingDim(g_ringDim ? g_ringDim : (1u << 12));
  } else {
    parameters.SetSecurityLevel(HEStd_128_classic);
    if (g_ringDim) parameters.SetRingDim(g_ringDim);   // else OpenFHE chooses from depth and the HE-Standard table
  }
  parameters.SetNumLargeDigits(3);
  parameters.SetKeySwitchTechnique(HYBRID);
  parameters.SetScalingTechnique(FIXEDMANUAL);
  usint dcrtBits = 48, firstMod = 49;
  parameters.SetScalingModSize(dcrtBits);
  parameters.SetFirstModSize(firstMod);

  std::vector<uint32_t> levelBudget = {g_lb0, g_lb1};
  std::vector<uint32_t> bsgsDim = {0, 0};
  // depth formula copied from the fork's example (levelBudget + EvalMod depth + LUT depth), plus
  // g_extraDepth levels that the user pipeline needs around the FBT calls.
  usint depth = g_lb0 + g_lb1 + 1 + 5 + 4 + bits + 2 + g_extraDepth;
  parameters.SetMultiplicativeDepth(depth);

  CryptoContext<DCRTPoly> cc = GenCryptoContext(parameters);
  cc->Enable(PKE);
  cc->Enable(KEYSWITCH);
  cc->Enable(LEVELEDSHE);
  cc->Enable(ADVANCEDSHE);
  cc->Enable(FHE);
  // NOTE: do NOT cc->Enable(FBTS): in sec-CKKS that flag makes Decode() std::round() every slot to an integer
  // (ckkspackedencoding.cpp), which destroys real-valued outputs.  EvalFuncBootstrap does not check it.

  uint32_t ringDim = cc->GetRingDimension();
  PROG("context created: N=" << ringDim << ", depth=" << depth << ", slots=" << ringDim / 2);
  if (numSlots == 0) numSlots = ringDim / 2;   // 0 => fully packed (the ONLY layout EvalFuncBootstrap supports)
  if (numSlots > ringDim / 2) throw std::runtime_error("numSlots > N/2");
  PROG("FBT setup ...");
  cc->EvalFuncBootstrapSetup(levelBudget, bsgsDim, numSlots, bits);
  PROG("FBT setup done");

  auto kp = cc->KeyGen();
  cc->EvalMultKeyGen(kp.secretKey);
  PROG("bootstrap key generation ...");
  cc->EvalBootstrapKeyGen(kp.secretKey, numSlots);
  PROG("bootstrap keys done");
  if (!rotIdx.empty()) PROG("rotation keys: " << rotIdx.size());
  if (!rotIdx.empty()) cc->EvalRotateKeyGen(kp.secretKey, rotIdx);
  // EvalFuncBootstrap returns f(x) + i*f(0) per slot (the imaginary input part is 0 -> table node 0).  The real part
  // is recovered with ONE conjugation (automorphism M-1): see fbt() in bench_softmax.cpp.
  cc->EvalAutomorphismKeyGen(kp.secretKey, std::vector<usint>{(usint)(cc->GetCyclotomicOrder() - 1)});   // no-op if the bootstrap keys already contain it
  auto conjKey = std::make_shared<std::map<usint, EvalKey<DCRTPoly>>>(CryptoContextImpl<DCRTPoly>::GetEvalAutomorphismKeyMap(kp.secretKey->GetKeyTag()));
  if (!conjKey || !conjKey->count(cc->GetCyclotomicOrder() - 1)) throw std::runtime_error("conjugation key missing");

  // logQP: sum of the bit sizes of the Q chain (P primes are not reported by this API; logged separately)
  double logQ = 0;
  for (auto& m : cc->GetCryptoParameters()->GetElementParams()->GetParams())
    logQ += std::log2(m->GetModulus().ConvertToDouble());
  std::ostringstream js;
  js << "{\"ringDim\":" << ringDim << ",\"logQ\":" << logQ << ",\"depth\":" << depth << ",\"scalingBits\":" << dcrtBits
     << ",\"firstModBits\":" << firstMod << ",\"levelBudget\":[" << g_lb0 << "," << g_lb1 << "],\"p\":" << p
     << ",\"order\":" << order << ",\"numSlots\":" << numSlots << ",\"secLevel\":\""
     << (g_insecure ? "NOT_SET(INSECURE_TEST)" : "HEStd_128_classic") << "\",\"secretKeyDist\":\"SPARSE_TERNARY\""
     << ",\"ksTech\":\"HYBRID\",\"numLargeDigits\":3,\"scaling\":\"FIXEDMANUAL\"}";
  return Ctx{cc, kp, numSlots, p, order, ringDim, js.str(), depth, depth - g_lb1, conjKey};
}
