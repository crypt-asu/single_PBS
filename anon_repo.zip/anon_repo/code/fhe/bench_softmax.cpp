// bench_softmax.cpp -- single harness that produces EVERY FHE number of the paper.
//
// Built and functionally tested against sec-CKKS (jdumezy/sec-ckks) at N=2^12 --insecure in the authoring sandbox.
// Timings from --insecure runs MUST NOT be reported.
// First run:  ./bench_softmax --mode selftest      (checks enc/dec, rotations, slot-sum)
//
// Modes
//   selftest   : sanity checks, no timing
//   calibrate  : what EvalFuncBootstrap really does with a real-valued index (round / linear /
//                Hermite?), its argument/output convention, and what happens out of range
//   stage      : stand-alone error of the exp LUT (Stage 2) and the reciprocal LUT (Stage 4)
//   e2e        : full Algorithm 1 for a sweep of d, component-level latency, measured levels, error
//   cheb       : leveled baseline (Chebyshev exp + Chebyshev/Newton reciprocal) in the SAME harness
//   boot       : latency of one plain EvalBootstrap-equivalent and of one FBT call (amortised model)
//   keys       : serialised key sizes + peak RSS
//   linear     : mat-vec latency, unhoisted (Listing 1) and hoisted rotations
// All results are appended as JSON lines to --out (one object per repetition), together with
// thread configuration, CPU model and the parameter dump of the context.
#include <malloc.h>
#include "ctx_setup.h"
#include <omp.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <sstream>
#include <string>
#include <vector>

using Clock = std::chrono::steady_clock;
static double ms_since(Clock::time_point t0) {
  return std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
}

// ------------------------------------------------------------------ cli / logging
struct Args {
  std::string mode = "selftest", out = "raw_fhe.jsonl", packing = "batched", scaling = "folded";
  std::vector<uint32_t> dims = {4, 8, 16, 32, 64, 128};
  uint32_t p = 256, order = 2, reps = 30, warmup = 2, rows = 8, seed = 1;
  double Omega = 10.0, smin = -1.0, delta = 1.5;   // delta = y* - max_i y_i. MEASURED (curve mode): the table end is unusable within ~8 nodes of the wrap boundary, so delta >= 8*Omega/(p-1) is REQUIRED. smin<0 => exp(-delta).
  uint32_t cheb_deg_exp = 15, cheb_deg_inv = 15, newton = 4;
  bool with_linear = false;
  std::string softmax = "fbt";
  uint32_t heads = 2, ffnmult = 2, guard = 8, ncal = 16;
  double margin = 0.2, eps = 1e-5;
  std::string ops = "fbt";   // layer mode: fbt | oracle (test-only plumbing check)
  std::string maxmode = "tour";   // layer mode, fbt Softmax: tour = row maximum by an FBT tournament | static = calibrated constant (oracle / ablation only)
  std::string calib_part = "all";   // calibrate mode: all | A (identity, model) | B (range) | D (imag, imagprod) | C (outrange); one process per part keeps the process below the memory limit
  int curve_order = 0;               // curve mode: 0 = all orders and the reciprocal tables (old behaviour); k>0 = only exp/sin/id at Hermite order k; -1 = only the reciprocal tables
  uint32_t calib_trials = 40;       // calibrate mode: number of random-index trials of the interpolation-model probe
  double tour_margin = 0.1;       // relative widening of the calibrated |difference| range of every tournament round
  double wscale = 1.0;   // weight magnitude (U(-w,w) with w = wscale/sqrt(dk))
};
static Args A;
static std::ofstream OUT;
static std::string cpu_model() {
  std::ifstream f("/proc/cpuinfo");
  std::string l;
  while (std::getline(f, l))
    if (l.rfind("model name", 0) == 0) return l.substr(l.find(':') + 2);
  return "unknown";
}
static long cur_rss_kb() {
  std::ifstream f("/proc/self/status");
  std::string l;
  while (std::getline(f, l))
    if (l.rfind("VmRSS:", 0) == 0) return std::stol(l.substr(6));
  return -1;
}
static long peak_rss_kb() {
  std::ifstream f("/proc/self/status");
  std::string l;
  while (std::getline(f, l))
    if (l.rfind("VmHWM:", 0) == 0) return std::stol(l.substr(6));
  return -1;
}
static std::string env_json() {
  std::ostringstream o;
  o << "\"threads\":" << omp_get_max_threads() << ",\"OMP_NUM_THREADS\":\""
    << (getenv("OMP_NUM_THREADS") ? getenv("OMP_NUM_THREADS") : "unset") << "\",\"cpu\":\"" << cpu_model()
    << "\",\"peak_rss_kb\":" << peak_rss_kb();
  return o.str();
}
static void log_json(const std::string& body, const Ctx* c = nullptr) {
  OUT << "{\"mode\":\"" << A.mode << "\"," << body << "," << env_json();
  if (c) OUT << ",\"params\":" << c->paramsJson;
  OUT << "}\n";
  OUT.flush();
}

// ------------------------------------------------------------------ helpers
static CT enc(Ctx& c, const std::vector<double>& v, int level = -1) {
  // fresh inputs of the first FBT are encrypted with only levelBudget[1] limbs left (as in the fork's example)
  Plaintext pt = c.cc->MakeCKKSPackedPlaintext(v, 1, level < 0 ? c.inLevel : (uint32_t)level, nullptr, c.slots);
  return c.cc->Encrypt(c.kp.publicKey, pt);
}
static std::vector<double> dec(Ctx& c, const CT& ct, size_t n) {
  Plaintext pt;
  c.cc->Decrypt(c.kp.secretKey, ct, &pt);
  pt->SetLength(n);
  return pt->GetRealPackedValue();
}
static uint32_t lvl(const CT& ct) { return ct->GetLevel(); }  // number of levels consumed so far

static std::vector<int32_t> rot_set(uint32_t d, bool batched, uint32_t slots) {
  std::vector<int32_t> r;
  for (uint32_t s = 1; s < d; s <<= 1) {
    r.push_back((int32_t)s);
    if (batched) r.push_back(-(int32_t)s);
  }
  for (uint32_t i = 1; i < d; ++i) r.push_back((int32_t)i);   // diagonal mat-vec
  std::sort(r.begin(), r.end());
  r.erase(std::unique(r.begin(), r.end()), r.end());
  (void)slots;
  return r;
}

// Algorithm 1, Step 3: log-time slot-sum.  sparse: slots == d (cyclic mod d) -> total in every slot.
//                      batched: B rows of length d in N/2 slots -> block sums via mask + broadcast (+1 level)
static CT slot_sum(Ctx& c, CT s, uint32_t d, bool batched, double* t_ms = nullptr) {
  auto t0 = Clock::now();
  for (uint32_t j = 1; j < d; j <<= 1) s = c.cc->EvalAdd(s, c.cc->EvalRotate(s, (int32_t)j));
  if (batched) {
    std::vector<double> m(c.slots, 0.0);
    for (uint32_t i = 0; i < c.slots; i += d) m[i] = 1.0;
    // FIXEDMANUAL: the plaintext must sit at the ciphertext's level and the product is rescaled by hand (1 level)
    s = c.cc->EvalMult(s, c.cc->MakeCKKSPackedPlaintext(m, 1, s->GetLevel(), nullptr, c.slots));
    c.cc->ModReduceInPlace(s);
    for (uint32_t j = 1; j < d; j <<= 1) s = c.cc->EvalAdd(s, c.cc->EvalRotate(s, -(int32_t)j));
  }
  if (t_ms) *t_ms = ms_since(t0);
  return s;
}

// The ONLY place where EvalFuncBootstrap is invoked.  f receives what the library hands to it; see
// `calibrate` for the empirical convention (index in [0,p) vs. other) and keep this wrapper in sync.
// EvalFuncBootstrap's SlotsToCoeffs uses plaintexts precomputed for ONE level: the input must sit at exactly
// level `inLevel` (= depth - levelBudget[1]).  Inputs that are shallower are level-reduced (free: drops limbs);
// deeper ones cannot be bootstrapped and abort the run.
static CT fbt(Ctx& c, const CT& ct, const std::function<double(double)>& f) {
  CT in = ct->Clone();
  uint32_t l = in->GetLevel();
  if (l > c.inLevel) throw std::runtime_error("FBT input consumed " + std::to_string(l) + " levels > allowed " + std::to_string(c.inLevel));
  if (l < c.inLevel) c.cc->LevelReduceInPlace(in, nullptr, c.inLevel - l);
  // MEASURED (layer mode, LAYER_DEBUG): EvalFuncBootstrap returns f(Re x) + i*f(0) in every slot, because the imaginary
  // part of the input (0) is looked up at table node 0 as well.  Products of two raw outputs then carry the bias
  // -Im(a)Im(b) (observed -0.1201 vs. predicted -0.1202).  We therefore tabulate f/2 and return o + conj(o) = f (real),
  // one key switch, no level.
  std::function<double(double)> half = [&f](double v) { return 0.5 * f(v); };
  CT o = c.cc->EvalFuncBootstrap(in, half, c.p, c.order);
  CT cj = c.cc->EvalAutomorphism(o, c.cc->GetCyclotomicOrder() - 1, *c.conjKey);
  CT res = c.cc->EvalAdd(o, cj);
  // Memory: glibc keeps freed arena memory of the (many) polynomial buffers that one FBT call allocates; without trimming the
  // resident size of the process grows with every call until the machine runs out of memory.  FBT_TRIM=0 disables the trim.
  static const bool dbg = getenv("FBT_MEM") != nullptr;
  static const bool trim = !(getenv("FBT_TRIM") && std::string(getenv("FBT_TRIM")) == "0");
  long before = dbg ? cur_rss_kb() : 0;
  o.reset(); cj.reset(); in.reset();
  if (trim) malloc_trim(0);
  if (dbg) { static int k = 0; std::cerr << "[mem] fbt call " << ++k << ": RSS " << before / 1024 << " MB -> " << cur_rss_kb() / 1024 << " MB after trim=" << trim << "\n"; }
  return res;
}

// FIXEDMANUAL: operands of EvalMult/EvalAdd must be at the same level; drop the shallower one.
static void match_levels(Ctx& c, CT& a, CT& b) {
  uint32_t la = a->GetLevel(), lb = b->GetLevel();
  if (la < lb) c.cc->LevelReduceInPlace(a, nullptr, lb - la);
  else if (lb < la) c.cc->LevelReduceInPlace(b, nullptr, la - lb);
}

static std::vector<double> exact_softmax(const std::vector<double>& y) {
  double m = *std::max_element(y.begin(), y.end()), s = 0;
  std::vector<double> e(y.size());
  for (size_t i = 0; i < y.size(); ++i) s += (e[i] = std::exp(y[i] - m));
  for (auto& v : e) v /= s;
  return e;
}
struct Err { double mae = 0, mx = 0; size_t n = 0; };
static void acc(Err& e, double a, double b) { double d = std::fabs(a - b); e.mae += d; e.mx = std::max(e.mx, d); e.n++; }

// ------------------------------------------------------------------ modes
static void mode_selftest() {
  uint32_t d = 8;
  Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));      // fully packed: the only layout FBT supports
  uint32_t B = c.slots / d;
  std::vector<double> v(c.slots);
  for (uint32_t i = 0; i < c.slots; ++i) v[i] = 1 + (i % d) + 0.01 * (i / d % 5);   // row b has sum 36 + 0.08*b%...
  auto ct = enc(c, v);
  auto r = dec(c, ct, c.slots);
  double e0 = 0;
  for (uint32_t i = 0; i < c.slots; ++i) e0 = std::max(e0, std::fabs(r[i] - v[i]));
  auto s = dec(c, slot_sum(c, ct, d, true), c.slots);
  double e1 = 0;
  for (uint32_t b = 0; b < B; ++b) {
    double ref = 0;
    for (uint32_t i = 0; i < d; ++i) ref += v[b * d + i];
    for (uint32_t i = 0; i < d; ++i) e1 = std::max(e1, std::fabs(s[b * d + i] - ref));
  }
  std::cout << "slots " << c.slots << " rows " << B << "\nenc/dec max err " << e0
            << "\nbatched block-sum max err (all rows, all slots) " << e1 << "\n";
  log_json("\"enc_dec_err\":" + std::to_string(e0) + ",\"blocksum_err\":" + std::to_string(e1), &c);
}

static CT mulr(Ctx& c, CT a, CT b);
// calibrate: determines the semantic of EvalFuncBootstrap on real-valued inputs.
static void mode_calibrate() {
  uint32_t d = 64;
  Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
  double lo = -A.Omega, h = A.Omega / (A.p - 1);
  auto g = [&](double v) { return std::exp(lo + v * h); };   // candidate convention: f receives index v
  std::mt19937_64 rng(A.seed);
  auto on = [&](char ch) { return A.calib_part == "all" || A.calib_part[0] == ch; };
  if (on('A')) {
  // P1: identity -> input/output scale and argument convention
  for (double probe : {0.0, 1.0, 5.0, 17.0, (double)A.p / 2, (double)A.p - 1}) {
    std::vector<double> x(d, probe);
    auto out = dec(c, fbt(c, enc(c, x), [](double v) { return v; }), d);
    log_json("\"probe\":\"identity\",\"in\":" + std::to_string(probe) + ",\"out\":" + std::to_string(out[0]), &c);
  }
  // P2: non-integer indices: which interpolation model does the library implement?
  //     model predictions are computed in plaintext (round / linear / hermite3)
  for (uint32_t t = 0; t < A.calib_trials; ++t) {
    std::vector<double> x(d);
    for (auto& v : x) v = std::uniform_real_distribution<double>(0, A.p - 1.001)(rng);
    auto out = dec(c, fbt(c, enc(c, x), g), d);
    Err er, el, eh;
    for (uint32_t i = 0; i < d; ++i) {
      double v = x[i]; int k = (int)std::floor(v); double u = v - k;
      double y0 = g(k), y1 = g(k + 1), m0 = g(k) * h, m1 = g(k + 1) * h;
      double lin = y0 * (1 - u) + y1 * u;
      double u2 = u * u, u3 = u2 * u;
      double her = (2 * u3 - 3 * u2 + 1) * y0 + (u3 - 2 * u2 + u) * m0 + (-2 * u3 + 3 * u2) * y1 + (u3 - u2) * m1;
      acc(er, out[i], g(std::floor(v + 0.5)));
      acc(el, out[i], lin);
      acc(eh, out[i], her);
    }
    log_json("\"probe\":\"model\",\"mae_round\":" + std::to_string(er.mae / er.n) + ",\"mae_linear\":" +
             std::to_string(el.mae / el.n) + ",\"mae_hermite3\":" + std::to_string(eh.mae / eh.n) +
             ",\"max_round\":" + std::to_string(er.mx) + ",\"max_linear\":" + std::to_string(el.mx) +
             ",\"max_hermite3\":" + std::to_string(eh.mx), &c);
  }
  }
  if (on('B')) {
  // P3: out-of-range inputs: wrap-around (mod p) or saturation?
  for (double probe : {-0.5, -1.0, -5.0, -20.0, (double)A.p - 0.5, (double)A.p, (double)A.p + 1.0, (double)A.p + 20.0}) {
    std::vector<double> x(d, probe);
    auto out = dec(c, fbt(c, enc(c, x), g), d);
    log_json("\"probe\":\"range\",\"in\":" + std::to_string(probe) + ",\"out\":" + std::to_string(out[0]) +
             ",\"g_clamped\":" + std::to_string(g(std::min<double>(std::max(probe, 0.0), A.p - 1))) +
             ",\"g_wrapped\":" + std::to_string(g(std::fmod(std::fmod(probe, A.p) + A.p, A.p))), &c);
  }
  }
  if (on('D')) {
  // P5: imaginary part of the raw output.  The imaginary part of the (real-valued) input is 0 and is looked up at
  //     table node 0 as well, so every output slot is expected to be  g(Re x) + i*g(0).
  {
    // control function with a LARGE value at node 0 (the exp table has g(0)=e^-Omega ~ 0 and would hide the effect)
    auto g = [&](double v) { return 1.5 + std::sin(2.0 * M_PI * v / A.p); };
    std::vector<double> x(d);
    for (auto& v : x) v = std::uniform_real_distribution<double>(10, A.p - 12)(rng);
    CT in = enc(c, x);
    CT o = c.cc->EvalFuncBootstrap(in, g, c.p, c.order);
    Plaintext pt; c.cc->Decrypt(c.kp.secretKey, o, &pt); pt->SetLength(d);
    auto z = pt->GetCKKSPackedValue();
    double dev = 0, devre = 0, imax = 0;
    for (uint32_t i = 0; i < d; ++i) { dev = std::max(dev, std::fabs(z[i].imag() - g(0))); imax = std::max(imax, std::fabs(z[i].imag())); devre = std::max(devre, std::fabs(z[i].real() - g(x[i]))); }
    log_json("\"probe\":\"imag\",\"g0\":" + std::to_string(g(0)) + ",\"imag_dev_from_g0\":" + std::to_string(dev) + ",\"imag_absmax\":" + std::to_string(imax) +
             ",\"real_dev_from_g\":" + std::to_string(devre), &c);
    // product of two raw outputs, with and without the conjugation correction of fbt()
    CT o2 = c.cc->EvalFuncBootstrap(enc(c, x), g, c.p, c.order);
    CT pr = c.cc->EvalMult(o, o2); c.cc->ModReduceInPlace(pr);
    CT f1 = fbt(c, enc(c, x), g), f2 = fbt(c, enc(c, x), g);
    CT pc = mulr(c, f1, f2);
    auto ra = dec(c, pr, d), rb = dec(c, pc, d);
    double ea = 0, eb = 0; for (uint32_t i = 0; i < d; ++i) { double t = g(x[i]) * g(x[i]); ea = std::max(ea, std::fabs(ra[i] - t)); eb = std::max(eb, std::fabs(rb[i] - t)); }
    log_json("\"probe\":\"imagprod\",\"err_raw_product\":" + std::to_string(ea) + ",\"err_conj_product\":" + std::to_string(eb), &c);
  }
  }
  if (on('C')) {
  // P4: output range: is |output| limited (e.g. by p or by the scaling factor)?
  for (double amp : {0.5, 1.0, 2.0, 10.0, 85.0, 255.0}) {
    std::vector<double> x(d, 10.0);
    auto out = dec(c, fbt(c, enc(c, x), [&](double) { return amp; }), d);
    log_json("\"probe\":\"outrange\",\"amp\":" + std::to_string(amp) + ",\"out\":" + std::to_string(out[0]), &c);
  }
  }
}


// curve: dumps the FULL measured response curve (index -> output) of EvalFuncBootstrap for a given f, for every
// Hermite order 1..3, so that the interpolation model can be identified offline (code/fhe/fit_curve.py).
static void mode_curve() {
  Ctx c = make_ctx(0, A.p, A.order, rot_set(8, true, 0));
  double h = A.Omega / (A.p - 1);
  uint32_t S = c.slots, G = std::min<uint32_t>(S, 4096);      // G grid points over the index range [0, p)
  auto run = [&](const std::string& name, const std::function<double(double)>& f, int ord, uint32_t dd) {
    std::vector<double> x(S);
    for (uint32_t i = 0; i < S; ++i) x[i] = (double)A.p * (i % G) / (double)G;
    auto o = dec(c, c.cc->EvalFuncBootstrap(enc(c, x), f, c.p, ord), G);
    std::ostringstream js;
    js << "\"func\":\"" << name << "\",\"hermite_order\":" << ord << ",\"p\":" << A.p << ",\"Omega\":" << A.Omega
       << ",\"smin\":" << A.smin << ",\"d\":" << dd << ",\"G\":" << G << ",\"x\":[";
    for (uint32_t i = 0; i < G; ++i) js << (i ? "," : "") << x[i];
    js << "],\"y\":[";
    for (uint32_t i = 0; i < G; ++i) js << (i ? "," : "") << o[i];
    js << "]";
    log_json(js.str(), &c);
  };
  for (int ord = 1; ord <= 3; ++ord) {
    if (A.curve_order < 0 || (A.curve_order > 0 && ord != A.curve_order)) continue;
    run("exp", [&](double v) { return std::exp(-A.Omega + v * h); }, ord, 0);
    run("sin", [&](double v) { return std::sin(2 * M_PI * v / A.p); }, ord, 0);   // periodic control
    run("id", [](double v) { return v; }, ord, 0);
  }
  // reciprocal tables, explicit form f(v) = 1/(smin + v (d-smin)/(p-1)), at the configured Hermite order
  for (uint32_t dd : A.dims) {
    if (A.curve_order > 0) break;
    double a = (A.p - 1) / ((double)dd - A.smin);
    run("inv", [&](double v) { return 1.0 / (A.smin + v / a); }, (int)A.order, dd);
  }
}

// stage: stand-alone error of both LUT stages.
static void mode_stage() {
  uint32_t d = A.dims.back();
  Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
  std::mt19937_64 rng(A.seed);
  double h = A.Omega / (A.p - 1);
  for (uint32_t rep = 0; rep < A.reps; ++rep) {
    // Stage 2: exp
    std::vector<double> x(d);
    for (auto& v : x) v = std::uniform_real_distribution<double>(0, A.p - 1)(rng);
    auto o = dec(c, fbt(c, enc(c, x), [&](double v) { return std::exp(-A.Omega + v * h); }), d);
    Err e;
    for (uint32_t i = 0; i < d; ++i) acc(e, o[i], std::exp(-A.Omega + x[i] * h));
    log_json("\"stage\":\"exp\",\"rep\":" + std::to_string(rep) + ",\"mae\":" + std::to_string(e.mae / e.n) +
             ",\"max\":" + std::to_string(e.mx), &c);
    // Stage 4: reciprocal on [smin, dd]; the plaintext affine map is  v = (S - smin)(p-1)/(dd - smin)
    for (uint32_t dd : A.dims) {
      double a = (A.p - 1) / (dd - A.smin);
      std::vector<double> v(d), S(d);
      for (uint32_t i = 0; i < d; ++i) {
        S[i] = std::uniform_real_distribution<double>(A.smin, (double)dd)(rng);
        v[i] = (S[i] - A.smin) * a;
      }
      auto r = dec(c, fbt(c, enc(c, v), [&](double u) { return 1.0 / (A.smin + u / a); }), d);
      Err ei;
      for (uint32_t i = 0; i < d; ++i) acc(ei, r[i], 1.0 / S[i]);
      log_json("\"stage\":\"inv\",\"d\":" + std::to_string(dd) + ",\"rep\":" + std::to_string(rep) +
               ",\"mae\":" + std::to_string(ei.mae / ei.n) + ",\"max\":" + std::to_string(ei.mx), &c);
    }
  }
}

// e2e: Algorithm 1 with component timers and measured levels.
// Stage layout (scaling == "folded"): the scale a=(p-1)/(d-smin) is folded into the exp table
//   e~_j = a * exp(.),  S~ = sum e~_j = a*S,  idx_S = S~ - a*smin,  g_inv(v) = 1/(v + a*smin),
//   out_i = e~_i * (1/S~)  -> no extra outer level.  scaling == "explicit": one extra ct x const level.
static void mode_e2e() {
  bool batched = A.packing == "batched";
  for (uint32_t d : A.dims) {
    if (!batched) { std::cerr << "sparse packing is not supported by EvalFuncBootstrap in sec-CKKS; use --packing batched\n"; return; }
    Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
    uint32_t slots = c.slots;
    uint32_t B = batched ? slots / d : 1;
    std::mt19937_64 rng(A.seed + d);
    double a = (A.p - 1) / ((double)d - A.smin);
    double h = A.Omega / (A.p - 1);
    bool folded = A.scaling == "folded";
    double ea = folded ? a : 1.0;
    for (uint32_t rep = 0; rep < A.reps + A.warmup; ++rep) {
      // rows with exactly known maximum: y* = max + delta ; spread limited to Omega - delta (inside window)
      std::vector<double> idx(slots, 0.0);
      std::vector<std::vector<double>> Y(B, std::vector<double>(d));
      for (uint32_t b = 0; b < B; ++b) {
        for (uint32_t i = 0; i < d; ++i) Y[b][i] = std::uniform_real_distribution<double>(-(A.Omega - A.delta) * 0.98, 0.0)(rng);
        Y[b][0] = 0.0;                                   // exact max
        for (uint32_t i = 0; i < d; ++i) idx[b * d + i] = (Y[b][i] - 0.0 + A.Omega - A.delta) * (A.p - 1) / A.Omega;
      }
      // encrypting idx directly == Phase 1 with scale/shift folded into W and b (same single level);
      // use --with-linear to run the explicit diagonal mat-vec as Phase 1 (see mode `linear`).
      CT ct = enc(c, idx);
      auto T0 = Clock::now();
      uint32_t l0 = lvl(ct);
      auto t = Clock::now();
      CT e = fbt(c, ct, [&](double v) { return ea * std::exp(-A.Omega + v * h); });
      double t_exp = ms_since(t);
      uint32_t l_e = lvl(e);
      double t_sum;
      CT s = slot_sum(c, e, d, batched, &t_sum);
      t = Clock::now();
      CT sidx;
      if (folded) sidx = c.cc->EvalAdd(s, -a * A.smin);
      else {                                   // explicit scaling costs one extra outer level (FIXEDMANUAL: rescale by hand)
        sidx = c.cc->EvalMult(s, a);
        c.cc->ModReduceInPlace(sidx);
        sidx = c.cc->EvalAdd(sidx, -a * A.smin);
      }
      double t_pre = ms_since(t);
      t = Clock::now();
      // folded  : v = S~ - a*smin  with S~ = a*S   ->  1/S~ = 1/(v + a*smin)   (final product uses e~ = a*e)
      // explicit: v = a*(S - smin)                 ->  1/S  = 1/(v/a + smin)
      CT inv = fbt(c, sidx, [&](double v) { return folded ? 1.0 / (v + a * A.smin) : 1.0 / (v / a + A.smin); });
      double t_inv = ms_since(t);
      t = Clock::now();
      uint32_t l_inv = lvl(inv), l_s = lvl(sidx);   // explicit scaling adds a level before the second FBT
      match_levels(c, e, inv);
      CT outc = c.cc->EvalMult(e, inv);
      c.cc->ModReduceInPlace(outc);   // FIXEDMANUAL: explicit rescale (1 outer level)
      // levels consumed by the OUTER circuit between the two FBT calls and after the second one:
      //   (slot-sum incl. mask) + (final product);  Phase 1 (projection) is not part of this mode.
      uint32_t outer_lv = (l_s - l_e) + (lvl(outc) - l_inv);
      double t_mul = ms_since(t);
      double t_total = ms_since(T0);
      auto o = dec(c, outc, slots);
      Err er;
      for (uint32_t b = 0; b < B; ++b) {
        auto ref = exact_softmax(Y[b]);
        for (uint32_t i = 0; i < d; ++i) acc(er, o[b * d + i], ref[i] * (folded ? 1.0 : 1.0));
      }
      if (rep < A.warmup) continue;
      std::ostringstream js;
      js << "\"d\":" << d << ",\"packing\":\"" << A.packing << "\",\"scaling\":\"" << A.scaling << "\",\"rep\":" << rep - A.warmup
         << ",\"t_total_ms\":" << t_total << ",\"t_exp_fbt_ms\":" << t_exp << ",\"t_slotsum_ms\":" << t_sum
         << ",\"t_pre_ms\":" << t_pre << ",\"t_inv_fbt_ms\":" << t_inv << ",\"t_final_mul_ms\":" << t_mul
         << ",\"levels_in\":" << l0 << ",\"levels_after_exp\":" << l_e << ",\"outer_levels\":" << outer_lv << ",\"levels_out\":" << lvl(outc)
         << ",\"mae\":" << er.mae / er.n << ",\"max\":" << er.mx << ",\"rows\":" << B << ",\"delta\":" << A.delta;
      log_json(js.str(), &c);
    }
  }
}

// cheb: leveled baseline in the SAME context / threads (fully packed, B rows per ciphertext, fresh ciphertext at
// level 0 because the baseline has no bootstrapping).  FIXEDMANUAL: every ct x ct product is followed by an explicit
// ModReduce and operands are level-matched by hand.
static CT mulr(Ctx& c, CT a, CT b) {
  match_levels(c, a, b);
  CT r = c.cc->EvalMult(a, b);
  c.cc->ModReduceInPlace(r);
  return r;
}
static void mode_cheb() {
  for (uint32_t d : A.dims) {
    Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
    uint32_t B = c.slots / d, S = c.slots;
    std::mt19937_64 rng(A.seed + d);
    for (uint32_t rep = 0; rep < A.reps + A.warmup; ++rep) {
      std::vector<double> y(S);
      std::vector<std::vector<double>> Y(B, std::vector<double>(d));
      for (uint32_t b = 0; b < B; ++b) {
        for (uint32_t i = 0; i < d; ++i) Y[b][i] = std::uniform_real_distribution<double>(-A.Omega * 0.98, 0.0)(rng);
        Y[b][0] = 0.0;
        for (uint32_t i = 0; i < d; ++i) y[b * d + i] = Y[b][i];
      }
      CT ct = enc(c, y, 0);
      uint32_t l0 = lvl(ct);
      auto T0 = Clock::now();
      auto t = Clock::now();
      CT e = c.cc->EvalChebyshevFunction(std::function<double(double)>([](double x) { return std::exp(x); }), ct, -A.Omega, 0.0, A.cheb_deg_exp);
      double t_exp = ms_since(t);
      double t_sum;
      CT s = slot_sum(c, e, d, true, &t_sum);
      t = Clock::now();
      // reciprocal on [smin, d]: Chebyshev init + Newton  x <- x (2 - S x)
      CT x = c.cc->EvalChebyshevFunction(std::function<double(double)>([](double z) { return 1.0 / z; }), s, A.smin, (double)d, A.cheb_deg_inv);
      for (uint32_t it = 0; it < A.newton; ++it) {
        CT m = mulr(c, s, x);                       // S x
        CT m2 = c.cc->EvalSub(m, 2.0);              // S x - 2
        x = c.cc->EvalNegate(mulr(c, x, m2));       // x (2 - S x)
      }
      double t_inv = ms_since(t);
      t = Clock::now();
      CT outc = mulr(c, e, x);
      double t_mul = ms_since(t);
      double t_total = ms_since(T0);
      auto o = dec(c, outc, S);
      Err er;
      for (uint32_t b = 0; b < B; ++b) {
        auto ref = exact_softmax(Y[b]);
        for (uint32_t i = 0; i < d; ++i) acc(er, o[b * d + i], ref[i]);
      }
      if (rep < A.warmup) continue;
      std::ostringstream js;
      js << "\"d\":" << d << ",\"rep\":" << rep - A.warmup << ",\"t_total_ms\":" << t_total << ",\"t_exp_ms\":" << t_exp
         << ",\"t_slotsum_ms\":" << t_sum << ",\"t_inv_ms\":" << t_inv << ",\"t_final_mul_ms\":" << t_mul
         << ",\"levels_in\":" << l0 << ",\"levels_out\":" << lvl(outc) << ",\"cheb_deg_exp\":" << A.cheb_deg_exp
         << ",\"cheb_deg_inv\":" << A.cheb_deg_inv << ",\"newton\":" << A.newton << ",\"mae\":" << er.mae / er.n
         << ",\"max\":" << er.mx << ",\"rows\":" << B;
      log_json(js.str(), &c);
    }
  }
}

// boot: cost of one bootstrap-like refresh, for the amortised cost model
//   T_leveled(softmax) + (levels_consumed / L_outer) * T_boot   vs   T_fbt(softmax)
static void mode_boot() {
  uint32_t d = 64;
  Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
  std::vector<double> x(d, 3.0);
  for (uint32_t rep = 0; rep < A.reps + A.warmup; ++rep) {
    CT ct = enc(c, x);
    auto t = Clock::now();
    CT r = fbt(c, ct, [](double v) { return v; });   // identity FBT == one bootstrap incl. LUT evaluation
    double t_fbt = ms_since(t);
    // TODO: plain bootstrap for the same context: c.cc->EvalBootstrap(ct) if the fork keeps it available
    if (rep < A.warmup) continue;
    log_json("\"rep\":" + std::to_string(rep - A.warmup) + ",\"t_fbt_identity_ms\":" + std::to_string(t_fbt) +
             ",\"levels_after\":" + std::to_string(lvl(r)), &c);
  }
}

// output stream that only counts the bytes written (the serialised keys are tens of GB: never keep them in memory)
struct CountBuf : std::streambuf {
  uint64_t n = 0;
  int_type overflow(int_type ch) override { if (ch != traits_type::eof()) ++n; return ch; }
  std::streamsize xsputn(const char*, std::streamsize k) override { n += (uint64_t)k; return k; }
};
static void mode_keys() {
  uint32_t d = A.dims.back();
  Ctx c = make_ctx(0, A.p, A.order, rot_set(d, true, 0));
  CountBuf bm, br; std::ostream km(&bm), kr(&br);
  c.cc->SerializeEvalMultKey(km, SerType::BINARY);
  c.cc->SerializeEvalAutomorphismKey(kr, SerType::BINARY);
  log_json("\"evalmult_key_bytes\":" + std::to_string(bm.n) +
           ",\"automorphism_keys_bytes\":" + std::to_string(br.n), &c);
}

static void mode_linear() {
  for (uint32_t d : A.dims) {
    Ctx c = make_ctx(d, A.p, A.order, rot_set(d, false, d));
    std::mt19937_64 rng(A.seed + d);
    std::vector<std::vector<double>> W(d, std::vector<double>(d));
    std::vector<double> x(d), ref(d, 0.0);
    for (auto& r : W) for (auto& v : r) v = std::uniform_real_distribution<double>(-0.3, 0.3)(rng);
    for (auto& v : x) v = std::uniform_real_distribution<double>(-1, 1)(rng);
    for (uint32_t i = 0; i < d; ++i) for (uint32_t j = 0; j < d; ++j) ref[i] += W[i][j] * x[j];
    auto diag = [&](uint32_t i) {
      std::vector<double> dg(d);
      for (uint32_t j = 0; j < d; ++j) dg[j] = W[j][(j + i) % d];
      return c.cc->MakeCKKSPackedPlaintext(dg, 1, 0, nullptr, c.slots);
    };
    for (int hoisted = 0; hoisted < 2; ++hoisted)
      for (uint32_t rep = 0; rep < A.reps + A.warmup; ++rep) {
        CT ct = enc(c, x);
        auto t = Clock::now();
        CT acc_ct;
        std::shared_ptr<std::vector<DCRTPoly>> pre;
        if (hoisted) pre = c.cc->EvalFastRotationPrecompute(ct);
        for (uint32_t i = 0; i < d; ++i) {
          CT r = i == 0 ? ct : (hoisted ? c.cc->EvalFastRotation(ct, i, c.cc->GetCyclotomicOrder(), pre) : c.cc->EvalRotate(ct, i));
          CT m = c.cc->EvalMult(r, diag(i));
          acc_ct = i == 0 ? m : c.cc->EvalAdd(acc_ct, m);
        }
        c.cc->ModReduceInPlace(acc_ct);
        double tm = ms_since(t);
        auto o = dec(c, acc_ct, d);
        Err er;
        for (uint32_t i = 0; i < d; ++i) acc(er, o[i], ref[i]);
        if (rep < A.warmup) continue;
        log_json("\"d\":" + std::to_string(d) + ",\"hoisted\":" + std::to_string(hoisted) + ",\"rep\":" +
                     std::to_string(rep - A.warmup) + ",\"t_matvec_ms\":" + std::to_string(tm) +
                     ",\"levels_out\":" + std::to_string(lvl(acc_ct)) + ",\"max\":" + std::to_string(er.mx), &c);
      }
  }
}


// ------------------------------------------------------------------------------------------------
// attn: ONE attention head, n tokens, head width dk = n (power of two), plaintext weights, encrypted tokens.
//   per token i (one ciphertext, vector tiled over all slots with period n):
//       Q_i = x_i Wq,  K_i = x_i Wk,  V_i = x_i Wv                    (diagonal mat-vec, 1 level)
//   logits  L[i*n+j] = <Q_i, K_j>   (ct x ct, in-tile slot-sum, one-hot mask, accumulate)   -> batched layout
//   softmax over each row of n slots (FBT pipeline of Algorithm 1, or the leveled Chebyshev/Newton baseline)
//   output  O[i*n+c] = sum_j P[i,j] V[j,c]  via the diagonal method: sum_t P_t (.) V_t,
//           P_t[i*n+c] = P[i,(c+t)%n]  (two rotations + two masks),  V_t[i*n+c] = V[(c+t)%n, c]  (n masks)
// Out of scope here (stated in the paper): output projection, residual, LayerNorm, FFN, multi-head.
// The 1/sqrt(dk) factor and (for FBT) the index scale alpha=(p-1)/Omega are folded into Wq (plaintext, free).
// ------------------------------------------------------------------------------------------------
static Plaintext pt_at(Ctx& c, const std::vector<double>& v, uint32_t level) {
  return c.cc->MakeCKKSPackedPlaintext(v, 1, level, nullptr, c.slots);
}
static std::vector<int32_t> rot_set_attn(uint32_t n) {
  std::vector<int32_t> r;
  for (uint32_t t = 1; t < n; ++t) { r.push_back((int32_t)t); r.push_back(-(int32_t)t); }
  for (uint32_t s = 1; s < n; s <<= 1) { r.push_back((int32_t)s); r.push_back(-(int32_t)s); }
  std::sort(r.begin(), r.end()); r.erase(std::unique(r.begin(), r.end()), r.end());
  return r;
}
static void mode_attn() {
  bool use_fbt = (A.softmax == "fbt");
  for (uint32_t n : A.dims) {
    Ctx c = make_ctx(0, A.p, A.order, rot_set_attn(n));
    const uint32_t S = c.slots, dk = n;
    if ((uint64_t)n * n > S) { std::cerr << "n*n > slots\n"; continue; }
    std::mt19937_64 rng(A.seed + n);
    auto U = [&](double a) { return std::uniform_real_distribution<double>(-a, a)(rng); };
    const double alpha = (A.p - 1) / A.Omega, h = A.Omega / (A.p - 1);
    for (uint32_t rep = 0; rep < A.reps + A.warmup; ++rep) {
      // ---- plaintext model and reference ------------------------------------------------------------
      std::vector<std::vector<double>> X(n, std::vector<double>(dk)), Wq(dk, std::vector<double>(dk)),
          Wk = Wq, Wv = Wq;
      for (auto& r : X) for (auto& v : r) v = U(0.5);
      double w = A.wscale / std::sqrt((double)dk);
      for (auto* W : {&Wq, &Wk, &Wv}) for (auto& r : *W) for (auto& v : r) v = U(w);
      auto mm = [&](const std::vector<std::vector<double>>& M, const std::vector<std::vector<double>>& W) {
        std::vector<std::vector<double>> R(n, std::vector<double>(dk, 0.0));
        for (uint32_t i = 0; i < n; ++i) for (uint32_t k = 0; k < dk; ++k) for (uint32_t cc = 0; cc < dk; ++cc) R[i][cc] += M[i][k] * W[k][cc];
        return R;
      };
      auto Qr = mm(X, Wq), Kr = mm(X, Wk), Vr = mm(X, Wv);
      std::vector<std::vector<double>> Yl(n, std::vector<double>(n)), Oref(n, std::vector<double>(dk, 0.0));
      double ymax = -1e300;
      for (uint32_t i = 0; i < n; ++i) for (uint32_t j = 0; j < n; ++j) {
        double s = 0; for (uint32_t cc = 0; cc < dk; ++cc) s += Qr[i][cc] * Kr[j][cc];
        Yl[i][j] = s / std::sqrt((double)dk); ymax = std::max(ymax, Yl[i][j]);
      }
      // spread check for the FBT window: y* = max + delta must satisfy y_i >= y* - Omega
      double ymin = 1e300; for (auto& r : Yl) for (double v : r) ymin = std::min(ymin, v);
      bool admissible = (ymax + A.delta) - ymin <= A.Omega * 0.98;
      for (uint32_t i = 0; i < n; ++i) {
        auto P = exact_softmax(Yl[i]);
        for (uint32_t j = 0; j < n; ++j) for (uint32_t cc = 0; cc < dk; ++cc) Oref[i][cc] += P[j] * Vr[j][cc];
      }
      double ystar = ymax + A.delta;
      // ---- encrypt tokens (tiled with period n, level 0) ---------------------------------------------
      std::vector<CT> xs(n);
      for (uint32_t i = 0; i < n; ++i) {
        std::vector<double> v(S);
        for (uint32_t s = 0; s < S; ++s) v[s] = X[i][s % dk];
        xs[i] = enc(c, v, 0);
      }
      auto T0 = Clock::now(); auto t = Clock::now();
      // ---- projections: y[cc] = sum_k x[k] W[k][cc]; diag_t[cc] = W[(cc+t)%dk][cc] ---------------------
      auto project = [&](const CT& x, const std::vector<std::vector<double>>& W, double scale) {
        CT acc;
        for (uint32_t tt = 0; tt < dk; ++tt) {
          std::vector<double> dg(S);
          for (uint32_t s = 0; s < S; ++s) { uint32_t cc = s % dk; dg[s] = scale * W[(cc + tt) % dk][cc]; }
          CT r = tt == 0 ? x : c.cc->EvalRotate(x, (int32_t)tt);
          CT m = c.cc->EvalMult(r, pt_at(c, dg, x->GetLevel()));
          acc = tt == 0 ? m : c.cc->EvalAdd(acc, m);
        }
        c.cc->ModReduceInPlace(acc);
        return acc;
      };
      double qscale = use_fbt ? alpha / std::sqrt((double)dk) : 1.0 / std::sqrt((double)dk);
      std::vector<CT> Q(n), K(n), V(n);
      for (uint32_t i = 0; i < n; ++i) { Q[i] = project(xs[i], Wq, qscale); K[i] = project(xs[i], Wk, 1.0); V[i] = project(xs[i], Wv, 1.0); }
      double t_proj = ms_since(t); t = Clock::now();
      // ---- logits in batched layout -------------------------------------------------------------------
      CT L;
      for (uint32_t i = 0; i < n; ++i) for (uint32_t j = 0; j < n; ++j) {
        CT q = Q[i], k = K[j]; match_levels(c, q, k);
        CT pr = c.cc->EvalMult(q, k); c.cc->ModReduceInPlace(pr);                       // <- ct x ct, +1
        for (uint32_t s = 1; s < dk; s <<= 1) pr = c.cc->EvalAdd(pr, c.cc->EvalRotate(pr, (int32_t)s));  // total in every slot of the tile
        std::vector<double> oh(S, 0.0);
        for (uint32_t s = i * n + j; s < S; s += n * n) oh[s] = 1.0;
        CT mk = c.cc->EvalMult(pr, pt_at(c, oh, pr->GetLevel()));                       // select slot (i,j)  (scaleDeg 2)
        L = (i == 0 && j == 0) ? mk : c.cc->EvalAdd(L, mk);
      }
      c.cc->ModReduceInPlace(L);
      double t_logits = ms_since(t); t = Clock::now();
      uint32_t l_logits = lvl(L);
      // ---- Softmax over every row block of n slots -------------------------------------------------------
      CT Pc; double t_exp = 0, t_sum = 0, t_inv = 0, t_mul = 0;
      if (use_fbt) {
        double a = (A.p - 1) / ((double)n - A.smin);
        CT idx = c.cc->EvalAdd(L, alpha * (A.Omega - ystar));          // v = alpha*(y - y*) + alpha*Omega
        auto t1 = Clock::now();
        CT e = fbt(c, idx, [&](double v) { return a * std::exp(-A.Omega + v * h); });
        t_exp = ms_since(t1);
        CT s = slot_sum(c, e, n, true, &t_sum);
        t1 = Clock::now();
        CT sidx = c.cc->EvalAdd(s, -a * A.smin);
        CT inv = fbt(c, sidx, [&](double v) { return 1.0 / (v + a * A.smin); });
        t_inv = ms_since(t1); t1 = Clock::now();
        match_levels(c, e, inv);
        Pc = c.cc->EvalMult(e, inv); c.cc->ModReduceInPlace(Pc);
        t_mul = ms_since(t1);
      } else {
        CT xin = c.cc->EvalAdd(L, -ystar);
        auto t1 = Clock::now();
        CT e = c.cc->EvalChebyshevFunction(std::function<double(double)>([](double x) { return std::exp(x); }), xin, -A.Omega, 0.0, A.cheb_deg_exp);
        t_exp = ms_since(t1);
        CT s = slot_sum(c, e, n, true, &t_sum);
        t1 = Clock::now();
        CT x = c.cc->EvalChebyshevFunction(std::function<double(double)>([](double z) { return 1.0 / z; }), s, A.smin, (double)n, A.cheb_deg_inv);
        for (uint32_t it = 0; it < A.newton; ++it) { CT m = mulr(c, s, x); CT m2 = c.cc->EvalSub(m, 2.0); x = c.cc->EvalNegate(mulr(c, x, m2)); }
        t_inv = ms_since(t1); t1 = Clock::now();
        Pc = mulr(c, e, x);
        t_mul = ms_since(t1);
      }
      double t_softmax = ms_since(t); t = Clock::now();
      uint32_t l_soft = lvl(Pc);
      // ---- O = P V by the diagonal method ------------------------------------------------------------------
      CT Oc;
      for (uint32_t tt = 0; tt < n; ++tt) {
        // P_t[i*n+cc] = P[i,(cc+tt)%n]
        std::vector<double> mA(S), mB(S);
        for (uint32_t s = 0; s < S; ++s) { uint32_t cc = s % n; mA[s] = (cc + tt < n) ? 1.0 : 0.0; mB[s] = 1.0 - mA[s]; }
        CT Pt;
        if (tt == 0) Pt = Pc;
        else {
          CT r1 = c.cc->EvalMult(c.cc->EvalRotate(Pc, (int32_t)tt), pt_at(c, mA, Pc->GetLevel()));
          CT r2 = c.cc->EvalMult(c.cc->EvalRotate(Pc, (int32_t)tt - (int32_t)n), pt_at(c, mB, Pc->GetLevel()));
          Pt = c.cc->EvalAdd(r1, r2); c.cc->ModReduceInPlace(Pt);
        }
        // V_t[i*n+cc] = V[(cc+tt)%n][cc] = sum_j V_j (.) [ (cc+tt)%n == j ]
        CT Vt;
        for (uint32_t j = 0; j < n; ++j) {
          std::vector<double> mj(S, 0.0);
          for (uint32_t s = 0; s < S; ++s) mj[s] = (((s % n) + tt) % n == j) ? 1.0 : 0.0;
          CT m = c.cc->EvalMult(V[j], pt_at(c, mj, V[j]->GetLevel()));
          Vt = j == 0 ? m : c.cc->EvalAdd(Vt, m);
        }
        c.cc->ModReduceInPlace(Vt);
        match_levels(c, Pt, Vt);
        CT pv = c.cc->EvalMult(Pt, Vt);
        Oc = tt == 0 ? pv : c.cc->EvalAdd(Oc, pv);
      }
      c.cc->ModReduceInPlace(Oc);
      double t_pv = ms_since(t); double t_total = ms_since(T0);
      // ---- accuracy ------------------------------------------------------------------------------------------
      auto o = dec(c, Oc, S);
      Err eo;
      for (uint32_t i = 0; i < n; ++i) for (uint32_t cc = 0; cc < dk; ++cc) acc(eo, o[i * n + cc], Oref[i][cc]);
      if (rep < A.warmup) continue;
      std::ostringstream js;
      js << "\"n\":" << n << ",\"dk\":" << dk << ",\"softmax\":\"" << A.softmax << "\",\"rep\":" << rep - A.warmup
         << ",\"t_total_ms\":" << t_total << ",\"t_proj_ms\":" << t_proj << ",\"t_logits_ms\":" << t_logits
         << ",\"t_softmax_ms\":" << t_softmax << ",\"t_exp_ms\":" << t_exp << ",\"t_slotsum_ms\":" << t_sum
         << ",\"t_inv_ms\":" << t_inv << ",\"t_final_mul_ms\":" << t_mul << ",\"t_pv_ms\":" << t_pv
         << ",\"levels_after_logits\":" << l_logits << ",\"levels_after_softmax\":" << l_soft
         << ",\"levels_out\":" << lvl(Oc) << ",\"mae\":" << eo.mae / eo.n << ",\"max\":" << eo.mx
         << ",\"ymax\":" << ymax << ",\"ymin\":" << ymin << ",\"admissible\":" << (admissible ? 1 : 0) << ",\"delta\":" << A.delta;
      log_json(js.str(), &c);
    }
  }
}

#include "layer_mode.inc"

int main(int argc, char** argv) {
  for (int i = 1; i < argc; ++i) {
    std::string k = argv[i];
    auto nx = [&]() { return std::string(argv[++i]); };
    if (k == "--mode") A.mode = nx();
    else if (k == "--out") A.out = nx();
    else if (k == "--packing") A.packing = nx();
    else if (k == "--scaling") A.scaling = nx();
    else if (k == "--reps") A.reps = std::stoul(nx());
    else if (k == "--warmup") A.warmup = std::stoul(nx());
    else if (k == "--p") A.p = std::stoul(nx());
    else if (k == "--order") A.order = std::stoul(nx());
    else if (k == "--omega") A.Omega = std::stod(nx());
    else if (k == "--smin") A.smin = std::stod(nx());
    else if (k == "--delta") A.delta = std::stod(nx());
    else if (k == "--seed") A.seed = std::stoul(nx());
    else if (k == "--newton") A.newton = std::stoul(nx());
    else if (k == "--cheb-deg-exp") A.cheb_deg_exp = std::stoul(nx());
    else if (k == "--cheb-deg-inv") A.cheb_deg_inv = std::stoul(nx());
    else if (k == "--softmax") A.softmax = nx();
    else if (k == "--heads") A.heads = std::stoul(nx());
    else if (k == "--ffnmult") A.ffnmult = std::stoul(nx());
    else if (k == "--guard") A.guard = std::stoul(nx());
    else if (k == "--ncal") A.ncal = std::stoul(nx());
    else if (k == "--margin") A.margin = std::stod(nx());
    else if (k == "--eps") A.eps = std::stod(nx());
    else if (k == "--ops") A.ops = nx();
    else if (k == "--maxmode") A.maxmode = nx();
    else if (k == "--calib-part") A.calib_part = nx();
    else if (k == "--curve-order") A.curve_order = std::stoi(nx());
    else if (k == "--calib-trials") A.calib_trials = std::stoul(nx());
    else if (k == "--tour-margin") A.tour_margin = std::stod(nx());
    else if (k == "--wscale") A.wscale = std::stod(nx());
    else if (k == "--ringdim") g_ringDim = std::stoul(nx());
    else if (k == "--insecure") g_insecure = true;
    else if (k == "--lb0") g_lb0 = std::stoul(nx());
    else if (k == "--lb1") g_lb1 = std::stoul(nx());
    else if (k == "--extra-depth") g_extraDepth = std::stoul(nx());
    else if (k == "--dims") { A.dims.clear(); std::stringstream ss(nx()); std::string t; while (std::getline(ss, t, ',')) A.dims.push_back(std::stoul(t)); }
  }
  if (A.smin < 0) A.smin = std::exp(-A.delta);
  OUT.open(A.out, std::ios::app);
  std::map<std::string, std::function<void()>> M = {
      {"selftest", mode_selftest}, {"calibrate", mode_calibrate}, {"curve", mode_curve}, {"stage", mode_stage}, {"e2e", mode_e2e},
      {"cheb", mode_cheb}, {"boot", mode_boot}, {"keys", mode_keys}, {"linear", mode_linear}, {"attn", mode_attn}, {"layer", mode_layer}};
  if (!M.count(A.mode)) { std::cerr << "unknown mode\n"; return 1; }
  try {
    M[A.mode]();
  } catch (const std::exception& e) {   // one failing configuration must not abort the whole pipeline; the error is recorded
    std::string m = e.what();
    for (auto& ch : m) if (ch == '"' || ch == '\\' || ch == '\n') ch = ' ';
    std::cerr << "ERROR in mode " << A.mode << ": " << m << "\n";
    OUT << "{\"mode\":\"error\",\"failed_mode\":\"" << A.mode << "\",\"message\":\"" << m << "\"}\n";
  }
  return 0;
}
