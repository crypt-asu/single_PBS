#!/usr/bin/env bash
# One-shot reproduction of every number in the paper.  Run from code/.
#   ./run_all.sh emu     (CPU, seconds)           ./run_all.sh model   (GPU, A100)
#   THREADS=1 ./run_all.sh fhe   and   THREADS=<many> ./run_all.sh fhe     (CPU; report both)
# FHE part needs the sec-CKKS install:  OPENFHE_DIR=/path/to/sec-ckks/install/lib/OpenFHE
# All FHE knobs are environment variables (defaults = the configuration of the paper):
#   P=256 OMEGA=10 DELTA=1.5 ORDER=1 REPS=30 WARMUP=2 DIMS=8,32,128 ATTN_DIMS=8,16 LAYER_DIMS=4,8 LAYER_REPS=10 GUARD=8 LAYER_EXTRA=16 HEADS=2 FFNMULT=2 FHE_FLAGS=""
# FHE_FLAGS="--insecure --ringdim 4096" is for FUNCTIONAL smoke tests only: never report those timings.
set -euo pipefail
cd "$(dirname "$0")"
RES=${RES:-../results}
mkdir -p "$RES"
THREADS=${THREADS:-1}
export OMP_NUM_THREADS=$THREADS
export OMP_MAX_ACTIVE_LEVELS=${OMP_MAX_ACTIVE_LEVELS:-4}   # recommended by the sec-CKKS README
P=${P:-256}; OMEGA=${OMEGA:-10}; DELTA=${DELTA:-1.5}; ORDER=${ORDER:-1}; REPS=${REPS:-30}; WARMUP=${WARMUP:-2}
DIMS=${DIMS:-8,32,128}; ATTN_DIMS=${ATTN_DIMS:-8,16}; LAYER_DIMS=${LAYER_DIMS:-4,8}; LAYER_REPS=${LAYER_REPS:-10}; GUARD=${GUARD:-8}; LAYER_EXTRA=${LAYER_EXTRA:-16}; HEADS=${HEADS:-2}; FFNMULT=${FFNMULT:-2}; FHE_FLAGS=${FHE_FLAGS:-}

step=${1:-all}

if [[ $step == emu || $step == all ]]; then
  python3 emu/stage_errors.py --out "$RES"
fi

if [[ $step == model || $step == all ]]; then
  python3 model_study/model_study.py --model distilbert-base-uncased-finetuned-sst-2-english --dtype float64 --out "$RES/model_study_distilbert"
  python3 model_study/model_study.py --model textattack/bert-base-uncased-SST-2 --dtype float64 --out "$RES/model_study_bert"
fi

# Shared preparation of the FHE steps (build, binary invocation, helpers).  RAWNAME lets a partial step write its own file.
fhe_prep() {
  BUILD=${BUILD:-build}
  mkdir -p "$BUILD" && (cd "$BUILD" && cmake ../fhe -DCMAKE_BUILD_TYPE=Release -DOpenFHE_DIR="${OPENFHE_DIR:?set OPENFHE_DIR=/path/to/sec-ckks/install/lib/OpenFHE}" >/dev/null && make -j"$THREADS")
  RAW=$RES/${RAWNAME:-raw_fhe_t${THREADS}}.jsonl
  rm -f "$RAW"
  B="$BUILD/bench_softmax --p $P --omega $OMEGA --delta $DELTA --order $ORDER --reps $REPS --warmup $WARMUP $FHE_FLAGS --out $RAW"
  # ONE PROCESS PER DIMENSION: OpenFHE keeps evaluation keys in process-wide tables, so a second context in the same
  # process adds its keys to the first one's (about 93 GB per context at N=2^17 -> out of memory).
  each() { local mode=$1 dims=$2; shift 2; for d in ${dims//,/ }; do echo "[$(date +%T)] $mode d=$d $*"; $B --mode "$mode" --dims "$d" "$@" || echo "[$(date +%T)] FAILED: $mode d=$d $*"; done; }
  LY="--heads $HEADS --ffnmult $FFNMULT --guard $GUARD --extra-depth $LAYER_EXTRA --maxmode ${MAXMODE:-tour}"
}
fhe_core() {
  # curve: one process per Hermite order (a process keeps the memory of every FBT precomputation it triggers), then the reciprocal tables
  for k in 1 2 3; do echo "[$(date +%T)] curve order $k"; $B --mode curve --dims "${DIMS%%,*}" --curve-order $k || echo "[$(date +%T)] FAILED: curve order $k"; done
  each curve  "$DIMS" --curve-order -1
  each stage  "$DIMS"
  each e2e    "$DIMS" --scaling folded
  each e2e    "$DIMS" --scaling explicit
  each cheb   "$DIMS"
  each cheb   "$DIMS" --newton 2
  each attn   "$ATTN_DIMS" --softmax cheb
  each attn   "$ATTN_DIMS" --softmax fbt
}
fhe_layer() {
  # complete encoder layer: plumbing check (oracle, test-only), then real FBT, and the leveled-Softmax baseline
  each layer  "$LAYER_DIMS" $LY --ops oracle --reps 1 --warmup 0
  each layer  "$LAYER_DIMS" $LY --reps "$LAYER_REPS" --ops fbt --softmax fbt
  each layer  "$LAYER_DIMS" $LY --reps "$LAYER_REPS" --ops fbt --softmax cheb
}
fhe_rest() {
  echo "[$(date +%T)] boot";       $B --mode boot
  each keys   "$DIMS"
  each linear "$DIMS"
}

if [[ $step == fhe || $step == all ]]; then
  fhe_prep
  echo "[$(date +%T)] selftest";   $B --mode selftest
  echo "[$(date +%T)] calibrate";  $B --mode calibrate
  each curve  "$DIMS"
  each stage  "$DIMS"
  each e2e    "$DIMS" --scaling folded
  each e2e    "$DIMS" --scaling explicit
  each cheb   "$DIMS"
  each cheb   "$DIMS" --newton 2
  each attn   "$ATTN_DIMS" --softmax cheb
  each attn   "$ATTN_DIMS" --softmax fbt
  fhe_layer
  fhe_rest
  echo "[$(date +%T)] tables"
  python3 make_tables.py --raw "$RAW" --out "$RES"
fi

# Partial steps (used to resume after the core measurements): ./run_all.sh layer ; ./run_all.sh rest
if [[ $step == calib ]]; then
  RAWNAME=raw_fhe_t${THREADS}_calib; BUILD=${BUILD:-build_new}; fhe_prep
  echo "[$(date +%T)] selftest";   $B --mode selftest
  # one process per part: every FBT call keeps memory in the process, 3 parts stay well below the limit
  for part in A B D C; do echo "[$(date +%T)] calibrate part $part"; $B --mode calibrate --calib-trials "${CALIB_TRIALS:-8}" --calib-part $part; done
fi
if [[ $step == core ]]; then
  RAWNAME=raw_fhe_t${THREADS}_core; BUILD=${BUILD:-build_new}; fhe_prep; fhe_core
fi
if [[ $step == layer ]]; then
  RAWNAME=raw_fhe_t${THREADS}_layer; BUILD=${BUILD:-build_new}; fhe_prep; fhe_layer
fi
if [[ $step == rest ]]; then
  RAWNAME=raw_fhe_t${THREADS}_rest; BUILD=${BUILD:-build_new}; fhe_prep; fhe_rest
fi
