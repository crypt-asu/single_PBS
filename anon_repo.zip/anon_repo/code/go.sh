#!/usr/bin/env bash
# Resumable orchestrator for the FHE measurements (single repetition).  Start with:  nohup setsid bash go.sh > /content/go.log 2>&1 &
# Every step leaves a marker file; after an interruption just start it again and it continues with the first unfinished step.
set -u
cd "$(dirname "$0")"
export OPENFHE_DIR=${OPENFHE_DIR:-/content/sec-ckks/install/lib/OpenFHE}
export RES=${RES:-/content/fhe_results} THREADS=${THREADS:-48}
export REPS=${NEW_REPS:-1} WARMUP=${NEW_WARMUP:-0} LAYER_REPS=${NEW_LAYER_REPS:-1} MAXMODE=tour CALIB_TRIALS=${CALIB_TRIALS:-8}
export OMP_MAX_ACTIVE_LEVELS=4
export FBT_MEM=1    # per-FBT resident-memory log lines ([mem] ...); malloc_trim after every FBT call is on by default (FBT_TRIM=0 disables it)
export LD_LIBRARY_PATH=$(dirname "$OPENFHE_DIR"):${LD_LIBRARY_PATH:-}   # OpenFHE shared libraries (…/install/lib)
mkdir -p "$RES"
echo "[$(date +%T)] go.sh: RES=$RES THREADS=$THREADS REPS=$REPS WARMUP=$WARMUP LAYER_REPS=$LAYER_REPS CALIB_TRIALS=$CALIB_TRIALS"
for st in calib layer core rest; do
  if [[ -f "$RES/done_$st" ]]; then echo "[$(date +%T)] $st: already done"; continue; fi
  echo "[$(date +%T)] === $st ==="
  if ./run_all.sh $st; then touch "$RES/done_$st"; else echo "[$(date +%T)] $st FAILED (continuing with the next step)"; fi
done
python3 make_tables.py --raw "$RES/raw_fhe_t${THREADS}_calib.jsonl" "$RES/raw_fhe_t${THREADS}_layer.jsonl" "$RES/raw_fhe_t${THREADS}_core.jsonl" "$RES/raw_fhe_t${THREADS}_rest.jsonl" --out "$RES"
echo "[$(date +%T)] ALL DONE"
