#!/usr/bin/env python3
"""Figures of the paper, generated from the result files (no number is typed in by hand).
   usage:  python3 make_figures.py --raw results/raw --tables results --out results/figs"""
import argparse, json, re, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("--raw", default="../results/raw")
ap.add_argument("--tables", default="../results")
ap.add_argument("--out", default="../results/figs")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
plt.rcParams.update({"font.size": 7.5, "axes.titlesize": 7.5, "axes.labelsize": 7.5, "legend.fontsize": 6.5,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "pdf.fonttype": 42, "ps.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 0.9})
OI = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9", "#F0E442", "#000000"]   # Okabe-Ito
W = 3.45

def jl(name): return [json.loads(l) for l in open(os.path.join(a.raw, name))]

# ------------------------------------------------------------------ response curve of the primitive
cv = jl("raw_fhe_t48_core.jsonl")
fun = {"exp": lambda v, p, Om: np.exp(-Om + v * Om / (p - 1)), "sin": lambda v, p, Om: np.sin(2 * np.pi * v / p)}
fig, ax = plt.subplots(figsize=(W, 2.1))
sty = {("exp", 1): (OI[0], "-", r"$\exp$, Hermite order 1"), ("exp", 2): (OI[3], "-", r"$\exp$, Hermite order 2"),
       ("sin", 1): (OI[2], "-", r"$\sin$ (periodic control)")}
for r in cv:
    k = (r["func"], r["hermite_order"])
    if k not in sty: continue
    x, y = np.array(r["x"]), np.array(r["y"])
    err = np.abs(fun[r["func"]](x, r["p"], r["Omega"]) - y)
    cell = np.floor(x + 1e-9).astype(int)                       # largest deviation inside each cell [k, k+1)
    env = np.array([err[cell == c].max() for c in range(r["p"])])
    c, ls, lab = sty[k]
    ax.semilogy(np.arange(r["p"]) + 0.5, np.maximum(env, 1e-7), color=c, ls=ls, lw=0.8, label=lab)
p = cv[0]["p"]
ax.axvspan(0, 8, color="0.88", lw=0); ax.axvspan(p - 8, p, color="0.88", lw=0)
ax.set_xlim(0, p); ax.set_ylim(1e-6, 3)
ax.set_xlabel("table index $v$ (cell = interval between two nodes)"); ax.set_ylabel("max deviation per cell")
ax.legend(loc="lower center", ncol=1, frameon=False, bbox_to_anchor=(0.5, 0.0))
fig.tight_layout(pad=0.3); fig.savefig(f"{a.out}/fig_curve.pdf"); plt.close(fig)

# ------------------------------------------------------------------ window study (parsed from tour_emu.tex)
rows = {}
for line in open(os.path.join(a.tables, "tour_emu.tex")):
    if line.startswith("tournament, wrap"):
        c = [t.strip() for t in line.rstrip("\\\n").rstrip().rstrip("\\").split("&")]
        om = c[1]
        vals = [c[2], c[4], c[6], c[8]]
        rows[om] = (float(c[2]), float(c[4].replace("\\%", "")), float(c[6]), float(c[8].replace("\\%", "")))
fixed = [10, 16, 24, 32, 48]
Dr = [rows[str(o)][1] for o in fixed]; Br = [rows[str(o)][3] for o in fixed]
Da = [rows[str(o)][0] for o in fixed]; Ba = [rows[str(o)][2] for o in fixed]
cal = [v for k, v in rows.items() if "g_L" in k and "0.1" in k][0]
fig, (a1, a2) = plt.subplots(2, 1, figsize=(W, 3.1), sharex=True)
xs = np.arange(len(fixed) + 1); labs = [str(o) for o in fixed] + ["calibrated\n$\\Omega_L$"]
a1.semilogy(xs[:-1], Dr, "o-", color=OI[0], ms=3, label="DistilBERT")
a1.semilogy(xs[:-1], Br, "s-", color=OI[1], ms=3, label="BERT-base")
a1.plot([xs[-1]], [1e-3], "v", color=OI[0], ms=4); a1.plot([xs[-1]], [1e-3], "v", color=OI[1], ms=4, mfc="none")
a1.annotate("0%", (xs[-1], 1e-3), textcoords="offset points", xytext=(-14, 3), fontsize=6.5)
a1.set_ylim(5e-4, 40); a1.set_ylabel("rows outside window (%)"); a1.legend(frameon=False, loc="upper right")
a2.plot(xs[:-1], Da, "o-", color=OI[0], ms=3); a2.plot(xs[:-1], Ba, "s-", color=OI[1], ms=3)
a2.plot([xs[-1]], [cal[0]], "v", color=OI[0], ms=4); a2.plot([xs[-1]], [cal[2]], "v", color=OI[1], ms=4, mfc="none")
a2.set_ylabel("SST-2 accuracy (%)"); a2.set_xticks(xs); a2.set_xticklabels(labs)
a2.set_xlabel("exponential window $\\Omega$ (tournament maximum, wrap indexing)")
fig.tight_layout(pad=0.3); fig.savefig(f"{a.out}/fig_window.pdf"); plt.close(fig)

# ------------------------------------------------------------------ g_L per layer (parsed from gap_study.tex)
dist, bert = [], []
for line in open(os.path.join(a.tables, "gap_study.tex")):
    m = re.match(r"^(\d+) &(.*)\\\\", line)
    if not m: continue
    c = [t.strip() for t in m.group(2).split("&")]
    if c[0]: dist.append((int(m.group(1)), float(c[0]), float(c[1])))
    if len(c) > 4 and c[4]: bert.append((int(m.group(1)), float(c[4]), float(c[5])))
fig, axs = plt.subplots(1, 2, figsize=(W, 1.7), gridspec_kw={"width_ratios": [6, 12]}, sharey=True)
for ax, d, t in ((axs[0], dist, "DistilBERT"), (axs[1], bert, "BERT-base")):
    L = np.array([r[0] for r in d]); ax.bar(L - 0.2, [r[1] for r in d], 0.4, color=OI[0], label="calibration")
    ax.bar(L + 0.2, [r[2] for r in d], 0.4, color=OI[1], label="validation"); ax.set_title(t)
    ax.set_xticks(L); ax.set_xlabel("layer")
axs[0].set_ylabel("max gap to row max"); axs[1].legend(frameon=False, loc="upper right")
fig.tight_layout(pad=0.3); fig.savefig(f"{a.out}/fig_gap.pdf"); plt.close(fig)

# ------------------------------------------------------------------ layer time breakdown
R = jl("raw_fhe_t48_layer.jsonl")
parts = [("t_proj_ms", "projections"), ("t_logits_ms", "logits"), ("t_softmax_ms", "Softmax"), ("t_pv_ms", "$PV$"),
         ("t_attnout_ms", "$W_O$ + back-conversion"), ("t_ln1_ms", "LayerNorm$_1$"), ("t_ffn_ms", "FFN + GELU"), ("t_ln2_ms", "LayerNorm$_2$")]
cfg = [(4, "cheb", "$n{=}4$ leveled"), (4, "fbt", "$n{=}4$ FBT"), (8, "cheb", "$n{=}8$ leveled"), (8, "fbt", "$n{=}8$ FBT")]
fig, ax = plt.subplots(figsize=(W, 2.5))
for i, (n, sm, lab) in enumerate(cfg):
    r = [x for x in R if x["n"] == n and x["softmax"] == sm and x["ops"] == "fbt"][0]
    left = 0.0
    for j, (k, name) in enumerate(parts):
        v = r[k] / 1000.0
        ax.barh(i, v, left=left, color=OI[j % 8] if j != 7 else "0.55", edgecolor="white", lw=0.3, label=name if i == 0 else None)
        left += v
ax.set_yticks(range(4)); ax.set_yticklabels([c[2] for c in cfg]); ax.invert_yaxis()
ax.set_xlabel("time (s), $N=2^{17}$, 48 threads, single run")
ax.legend(frameon=False, ncol=3, loc="upper center", fontsize=5.8, bbox_to_anchor=(0.45, -0.30), columnspacing=0.8, handlelength=1.0)
fig.tight_layout(pad=0.3); fig.savefig(f"{a.out}/fig_time.pdf"); plt.close(fig)
print("figures written to", a.out)
