#!/usr/bin/env python3
"""
range_study.py -- do the value ranges of a REAL pre-trained Transformer fit the (calibrated) lookup-table domains
of the non-Softmax functions of the encrypted layer?

For every encoder layer it records, over a calibration split and over a disjoint test split (non-padding tokens only):
   * the pre-activation range of the FFN GELU,
   * the range of the per-token variance seen by LayerNorm 1 and LayerNorm 2 (input of 1/sqrt(var+eps)),
   * the range of the attention logits (before Softmax) and of the Softmax row sum  S = sum_j exp(y_j - rowmax)  is
     covered by model_study.py (calibrated y*), so it is not repeated here.
A table domain is  [lo - m (hi-lo), hi + m (hi-lo)]  (additive margin for GELU, multiplicative 1 -/+ m for variances),
exactly as the encrypted layer (bench_softmax --mode layer) builds its domains.  The script reports the fraction of TEST
values that fall outside that domain and the number of FBT table nodes per unit (domain width / (p-1-2G)).

  python range_study.py --out ../../results --margin 0.2 --p 256 --guard 8
"""
import argparse, json, math, os
import numpy as np
import torch

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="distilbert-base-uncased-finetuned-sst-2-english")
ap.add_argument("--dataset", default="sst2")
ap.add_argument("--ncal", type=int, default=2000)
ap.add_argument("--ntest", type=int, default=0, help="0 = whole validation split")
ap.add_argument("--batch", type=int, default=32)
ap.add_argument("--maxlen", type=int, default=128)
ap.add_argument("--margin", type=float, default=0.2)
ap.add_argument("--p", type=int, default=256)
ap.add_argument("--guard", type=int, default=8)
ap.add_argument("--out", required=True)
ap.add_argument("--tag", default="")
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
ap.add_argument("--selftest", action="store_true")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
dev = args.device
dt = torch.float64

from transformers import AutoTokenizer, AutoModelForSequenceClassification
from datasets import load_dataset  # noqa

if args.selftest:
    from transformers import DistilBertConfig, DistilBertForSequenceClassification
    model = DistilBertForSequenceClassification(DistilBertConfig(vocab_size=200, dim=32, n_layers=3, n_heads=4, hidden_dim=64,
                                                                  max_position_embeddings=64, num_labels=2)).to(dev).to(dt).eval()
    tok = None
else:
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForSequenceClassification.from_pretrained(args.model, attn_implementation="eager").to(dev).to(dt).eval()


def split(name, n):
    if args.selftest:
        g = torch.Generator().manual_seed(1 if name == "train" else 2)
        return [dict(ids=torch.randint(1, 200, (int(torch.randint(5, 30, (1,), generator=g)),), generator=g).tolist()) for _ in range(n or 64)]
    try:
        ds = load_dataset("nyu-mll/glue", args.dataset, split=name)
    except Exception:
        ds = load_dataset("glue", args.dataset, split=name)
    return ds.select(range(min(n, len(ds)))) if n else ds


def batches(ds):
    for i in range(0, len(ds), args.batch):
        if args.selftest:
            ch = ds[i:i + args.batch]; T = max(len(c["ids"]) for c in ch)
            ids = torch.zeros(len(ch), T, dtype=torch.long); am = torch.zeros(len(ch), T, dtype=torch.long)
            for j, c in enumerate(ch):
                ids[j, :len(c["ids"])] = torch.tensor(c["ids"]); am[j, :len(c["ids"])] = 1
            yield {"input_ids": ids.to(dev), "attention_mask": am.to(dev)}
        else:
            enc = tok(ds[i:i + args.batch]["sentence"], padding=True, truncation=True, max_length=args.maxlen, return_tensors="pt")
            yield {k: v.to(dev) for k, v in enc.items()}


# ---- locate the hooks: per layer one GELU pre-activation (FFN first linear) and two LayerNorms -----------------------
gelu_mods, ln_mods = [], []
for name, m in model.named_modules():
    if name.endswith("ffn.lin1") or name.endswith("intermediate.dense"):
        gelu_mods.append(name)
    if isinstance(m, torch.nn.LayerNorm) and "embeddings" not in name:
        ln_mods.append(name)
L = len(gelu_mods)
assert L > 0 and len(ln_mods) == 2 * L, (len(gelu_mods), len(ln_mods))
state = {"mask": None, "rec": None}


def mk_gelu(i):
    def hook(mod, inp, out):
        v = out[state["mask"].bool()]
        r = state["rec"][("gelu", i)]; r[0] = min(r[0], v.min().item()); r[1] = max(r[1], v.max().item()); r[2].append(v.flatten().cpu().numpy())
    return hook


def mk_ln(i, which):
    def hook(mod, inp):
        x = inp[0][state["mask"].bool()]
        var = x.var(dim=-1, unbiased=False)
        r = state["rec"][(which, i)]; r[0] = min(r[0], var.min().item()); r[1] = max(r[1], var.max().item()); r[2].append(var.cpu().numpy())
    return hook


mods = dict(model.named_modules())
for i, nm in enumerate(gelu_mods):
    mods[nm].register_forward_hook(mk_gelu(i))
for i in range(L):
    mods[ln_mods[2 * i]].register_forward_pre_hook(mk_ln(i, "ln1"))
    mods[ln_mods[2 * i + 1]].register_forward_pre_hook(mk_ln(i, "ln2"))


def run(ds):
    rec = {(k, i): [1e300, -1e300, []] for k in ("gelu", "ln1", "ln2") for i in range(L)}
    state["rec"] = rec
    with torch.no_grad():
        for b in batches(ds):
            state["mask"] = b["attention_mask"]
            model(**b)
    return rec


cal = run(split("train", args.ncal))
tst = run(split("validation", args.ntest))
res, rows = {}, []
G, p, mg = args.guard, args.p, args.margin
for i in range(L):
    row = {}
    for k in ("gelu", "ln1", "ln2"):
        lo, hi = cal[(k, i)][0], cal[(k, i)][1]
        if k == "gelu":
            dmin, dmax = lo - mg * (hi - lo), hi + mg * (hi - lo)
        else:
            dmin, dmax = lo * (1 - mg), hi * (1 + mg)
        v = np.concatenate(tst[(k, i)][2])
        out = float(np.mean((v < dmin) | (v > dmax)))
        h = (dmax - dmin) / (p - 1 - 2 * G)
        row[k] = dict(cal_min=lo, cal_max=hi, test_min=float(v.min()), test_max=float(v.max()), dom_min=dmin, dom_max=dmax,
                      frac_outside=out, node_spacing=h, n_test=int(v.size))
    res[i + 1] = row
    rows.append(row)

json.dump(dict(model=args.model, margin=mg, p=p, guard=G, layers=res), open(f"{args.out}/ranges{args.tag}.json", "w"), indent=1)


def sci(x):
    if x == 0:
        return "0"
    e = int(np.floor(np.log10(abs(x)))); m = round(x / 10 ** e, 2)
    if m >= 10:
        m, e = m / 10, e + 1
    return f"${m:.2f}{{\\times}}10^{{{e}}}$"


t = [r"\begin{tabular}{@{}rrrrrrrrr@{}}", r"\toprule",
     r"layer & GELU in: cal.\ range & test range & outside & LN$_1$ var: cal.\ range & outside & LN$_2$ var: cal.\ range & outside & spacing GELU \\", r"\midrule"]
for i, r in enumerate(rows, 1):
    g, a, b = r["gelu"], r["ln1"], r["ln2"]
    t.append(f"{i} & [{g['cal_min']:.2f},\\,{g['cal_max']:.2f}] & [{g['test_min']:.2f},\\,{g['test_max']:.2f}] & {100 * g['frac_outside']:.3f}\\% & "
             f"[{a['cal_min']:.3g},\\,{a['cal_max']:.3g}] & {100 * a['frac_outside']:.3f}\\% & "
             f"[{b['cal_min']:.3g},\\,{b['cal_max']:.3g}] & {100 * b['frac_outside']:.3f}\\% & {g['node_spacing']:.3f} \\\\")
t += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/ranges{args.tag}.tex", "w").write("\n".join(t) + "\n")
print("done ->", args.out)
