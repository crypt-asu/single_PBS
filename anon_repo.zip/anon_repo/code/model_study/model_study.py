#!/usr/bin/env python3
"""
Real-model validation of the bounded-logit assumption and of the LUT-Softmax error
(Review A: "bounded-logit assumption not validated on real pretrained models";
 Review B: Monte-Carlo replaced by real LUT quantisation on a real model).

GPU-friendly (A100).  Plaintext emulation only: the Softmax inside every attention layer
of a pretrained Transformer is replaced by the emulation of Algorithm 1
(emu/lut_models.py).  Nothing here touches FHE.

Example (A100):
  python model_study.py --model distilbert-base-uncased-finetuned-sst-2-english \
        --dtype float64 --out ../../results/model_study_distilbert
  python model_study.py --model textattack/bert-base-uncased-SST-2 --dtype float64 \
        --out ../../results/model_study_bert

Outputs (in --out):  raw.json, domain.tex, prop.tex, hist_<cfg>.json
"""
import math
import argparse, json, os, sys, time, contextlib
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "emu"))
from lut_models import lut_softmax, load_curves

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="distilbert-base-uncased-finetuned-sst-2-english")
ap.add_argument("--dataset", default="sst2")
ap.add_argument("--split", default="validation")
ap.add_argument("--max_examples", type=int, default=0, help="0 = all")
ap.add_argument("--ncal", type=int, default=2000, help="#train examples for per-head y* calibration")
ap.add_argument("--margin", type=float, default=0.0, help="added to calibrated y*")
ap.add_argument("--batch", type=int, default=32)
ap.add_argument("--maxlen", type=int, default=128)
ap.add_argument("--dtype", default="float64", choices=["float32", "float64"])
ap.add_argument("--omega", type=float, default=10.0)
ap.add_argument("--p", type=int, default=256)
ap.add_argument("--exp_model", default="hermite3")
ap.add_argument("--inv_model", default="hermite3")
ap.add_argument("--smin", type=float, default=-1.0, help="<0 => exp(-delta)")
ap.add_argument("--delta", type=float, default=0.0, help="slack: rowmax mode uses y* = rowmax + delta (measured: delta must exceed the wrap zone of the primitive)")
ap.add_argument("--curve_file", default="", help="raw_fhe*.jsonl with `curve` records; needed for --exp_model/--inv_model empirical")
ap.add_argument("--curve_order", type=int, default=1)
ap.add_argument("--inv_smax", type=float, default=128.0, help="upper end of the reciprocal table domain used with the empirical model")
ap.add_argument("--newton", type=int, default=0)
ap.add_argument("--guard", type=int, default=8, help="guard nodes at each end of the |.| tables of the tournament")
ap.add_argument("--tour_margin", type=float, default=0.1, help="relative widening of the calibrated |difference| range per round")
ap.add_argument("--omega_calib", action="store_true", help="per-layer Omega = calibrated max(rowmax-logit)*(1+omega_margin)")
ap.add_argument("--omega_margin", type=float, default=0.1)
ap.add_argument("--configs", nargs="+",
                default=["rowmax:clamp", "rowmax:wrap", "calib:clamp", "calib:wrap", "fixed10:clamp", "fixed10:wrap"],
                help="<ystar-mode>:<clamp|wrap>; ystar-mode in rowmax|calib|calibmean|fixedC")
ap.add_argument("--out", required=True)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
ap.add_argument("--selftest_arch", default="distilbert", choices=["distilbert", "bert"])
ap.add_argument("--selftest", action="store_true", help="tiny random model + synthetic data, no network (smoke test)")
args = ap.parse_args()
if args.smin < 0:
    args.smin = math.exp(-args.delta)
os.makedirs(args.out, exist_ok=True)
torch.manual_seed(args.seed)
dev = args.device
dt = torch.float64 if args.dtype == "float64" else torch.float32

EXP_CURVE = INV_CURVE = None
if args.exp_model == "empirical" or args.inv_model == "empirical":
    EXP_CURVE, INV_CURVE = load_curves(args.curve_file, args.curve_order, int(args.inv_smax))

from transformers import AutoTokenizer, AutoModelForSequenceClassification
from datasets import load_dataset  # noqa

if args.selftest:
    if args.selftest_arch == "bert":
        from transformers import BertConfig, BertForSequenceClassification
        _cfg = BertConfig(vocab_size=200, hidden_size=32, num_hidden_layers=3, num_attention_heads=4,
                          intermediate_size=64, max_position_embeddings=64, num_labels=2, attn_implementation="eager")
        model = BertForSequenceClassification(_cfg).to(dev).to(dt).eval()
    else:
        from transformers import DistilBertConfig, DistilBertForSequenceClassification
        _cfg = DistilBertConfig(vocab_size=200, dim=32, n_layers=3, n_heads=4, hidden_dim=64,
                                max_position_embeddings=64, num_labels=2, attn_implementation="eager")
        model = DistilBertForSequenceClassification(_cfg).to(dev).to(dt).eval()
    tok = None
else:
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForSequenceClassification.from_pretrained(args.model, attn_implementation="eager").to(dev).to(dt).eval()
n_layers = getattr(model.config, "num_hidden_layers", None) or model.config.n_layers


def load_split(split, n):
    if args.selftest:
        g = torch.Generator().manual_seed(1 if split == "train" else 2)
        return [dict(ids=torch.randint(1, 200, (int(torch.randint(5, 30, (1,), generator=g)),), generator=g).tolist(),
                     label=int(torch.randint(0, 2, (1,), generator=g))) for _ in range(n or 64)]
    try:
        ds = load_dataset("nyu-mll/glue", args.dataset, split=split)
    except Exception:
        ds = load_dataset("glue", args.dataset, split=split)
    if n:
        ds = ds.select(range(min(n, len(ds))))
    return ds


def batches(ds):
    if args.selftest:
        for i in range(0, len(ds), args.batch):
            ch = ds[i:i + args.batch]
            T = max(len(c["ids"]) for c in ch)
            ids = torch.zeros(len(ch), T, dtype=torch.long)
            am = torch.zeros(len(ch), T, dtype=torch.long)
            for j, c in enumerate(ch):
                ids[j, :len(c["ids"])] = torch.tensor(c["ids"]); am[j, :len(c["ids"])] = 1
            yield {"input_ids": ids.to(dev), "attention_mask": am.to(dev)}, torch.tensor([c["label"] for c in ch], device=dev)
        return
    for i in range(0, len(ds), args.batch):
        chunk = ds[i:i + args.batch]
        enc = tok(chunk["sentence"], padding=True, truncation=True, max_length=args.maxlen, return_tensors="pt")
        yield {k: v.to(dev) for k, v in enc.items()}, torch.tensor(chunk["label"], device=dev)


ORIG_SOFTMAX = F.softmax


LOWV = {}
RMAXV = {}
GAPV = {}


def lut_abs(d, R, p, G):
    """|d| through a p-node table on [-R, R] with G guard nodes at each end; piecewise-linear between nodes (the kink
    makes every higher-order interpolant degenerate to this); values outside the table are clamped (optimistic)."""
    h = 2 * R / (p - 1 - 2 * G)
    lo = -R - G * h
    idx = ((d - lo) / h).clamp(0, p - 1 - 1e-9)
    i0 = idx.floor()
    f = idx - i0
    v0 = (lo + i0 * h).abs(); v1 = (lo + (i0 + 1) * h).abs()
    return v0 * (1 - f) + v1 * f


class SoftmaxPatch:
    """Replaces F.softmax(scores, dim=-1) on 4-D attention scores by the LUT emulation."""

    def __init__(self, cfg, calib=None):
        self.ystar_mode, self.mode = cfg.split(":")
        self.calib = calib
        self.layer = 0
        self.record = calib is None and False
        self.maxima = {}       # for calibration pass
        self.maxima_mean = {}  # per-head max of (rowmax - rowmean), for the calibmean mode
        self.minima = {}       # per-head min of the valid logits (padding value of the tournament)
        self.rmax = {}         # (layer, round) -> per-head max |difference| seen by the |.| table of the tournament
        self.gapmax = {}
        self.collect_tour = False
        self.stats = {}        # per layer accumulators
        self.collect_max = False

    def reset_forward(self):
        self.layer = 0

    def _acc(self, L, key, val, cnt=None, mx=False):
        d = self.stats.setdefault(L, {})
        if mx:
            d[key] = max(d.get(key, 0.0), float(val))
        else:
            d[key] = d.get(key, 0.0) + float(val)


    def tournament(self, x, valid, L):
        """Row maximum by a pairwise tournament: M <- (M + M_shift + |M - M_shift|)/2 with |.| evaluated by a p-node
        look-up table (one FBT call per round on ALL rows, log2(K) rounds).  Padding keys are replaced by the calibrated
        minimum of the head so that they never win."""
        ell = LOWV[L].view(1, -1, 1, 1).to(x.dtype)
        M = torch.where(valid, x, ell.expand_as(x))
        K = M.shape[-1]; Kp = 1 << (K - 1).bit_length()
        if Kp > K:
            M = torch.cat([M, ell.expand(*M.shape[:-1], Kp - K)], dim=-1)
        r, st = 0, 1
        while st < Kp:
            part = torch.roll(M, -st, dims=-1)
            d = M - part
            if self.collect_tour:
                cur = d.abs().amax(dim=(0, 2, 3))
                old = self.rmax.get((L, r)); self.rmax[(L, r)] = cur if old is None else torch.maximum(old, cur)
                a = d.abs()
            else:
                R = (RMAXV[(L, r)] * (1.0 + args.tour_margin)).view(1, -1, 1, 1).to(x.dtype)
                a = lut_abs(d, R, args.p, args.guard)
            M = 0.5 * (M + part + a)
            st *= 2; r += 1
        return M[..., :1]

    def __call__(self, x, dim=-1, _stacklevel=3, dtype=None):
        if x.dim() != 4 or dim not in (-1, 3):
            return ORIG_SOFTMAX(x, dim=dim, dtype=dtype)
        L = self.layer % n_layers
        self.layer += 1
        valid = x > -1e4
        xv = x.masked_fill(~valid, float("-inf"))
        rowmax = xv.max(-1, keepdim=True).values
        if self.collect_tour:
            self.tournament(x, valid, L)
            return ORIG_SOFTMAX(x, dim=-1)
        cnt = valid.sum(-1, keepdim=True).clamp(min=1)
        rowmean = x.masked_fill(~valid, 0.0).sum(-1, keepdim=True) / cnt      # mean over the valid keys (one slot-sum, no FBT)
        if self.collect_max:
            hm = xv.amax(dim=(0, 2, 3))                         # per head
            old = self.maxima.get(L)
            self.maxima[L] = hm if old is None else torch.maximum(old, hm)
            mn = x.masked_fill(~valid, float("inf")).amin(dim=(0, 2, 3))
            oldm = self.minima.get(L); self.minima[L] = mn if oldm is None else torch.minimum(oldm, mn)
            gm = torch.where(valid.any(-1, keepdim=True), rowmax - rowmean, torch.full_like(rowmax, float("-inf"))).amax(dim=(0, 2, 3))
            old = self.maxima_mean.get(L)
            self.maxima_mean[L] = gm if old is None else torch.maximum(old, gm)
            g = (rowmax - x).masked_fill(~valid, 0.0).max().item()
            self.gapmax[L] = max(self.gapmax.get(L, 0.0), g)
            return ORIG_SOFTMAX(x, dim=-1)
        if self.ystar_mode == "rowmax":
            ystar = rowmax + args.delta
        elif self.ystar_mode == "tour":                          # y* = tournament maximum (FBT |.| tables) + delta
            ystar = self.tournament(x, valid, L) + args.delta
        elif self.ystar_mode == "calibmean":                    # y* = rowmean + C_head, C_head = max over calibration rows of (rowmax - rowmean)
            ystar = rowmean + (CALIB_MEAN[L] + args.margin).view(1, -1, 1, 1).to(x.dtype)
        elif self.ystar_mode == "calib":
            ystar = (self.calib[L] + args.margin).view(1, -1, 1, 1).to(x.dtype).expand_as(rowmax)
        else:                                                    # fixed<C>
            C = float(self.ystar_mode[len("fixed"):])
            ystar = torch.full_like(rowmax, C)
        n_keys = x.shape[-1]
        y = torch.where(valid, x, ystar.expand_as(x))
        om = (GAPV[L] + args.delta) * (1.0 + args.omega_margin) if args.omega_calib else args.omega
        a, e, S = lut_softmax(y, ystar, n_keys, Omega=om, p=args.p, exp_model=args.exp_model,
                              inv_model=args.inv_model, smin=args.smin, mode=self.mode, exp_curve=EXP_CURVE, inv_curve=INV_CURVE,
                              smax=(args.inv_smax if args.inv_model == "empirical" else None),
                              newton=args.newton, mask=valid.to(x.dtype))
        a = a * valid.to(x.dtype)
        ref = ORIG_SOFTMAX(x, dim=-1)
        # ---- statistics (valid entries only) -------------------------------------------------------
        below = valid & ((x - ystar) < -om)
        above = valid & (x > ystar)
        tail = (ref * below).sum(-1)                              # exact prob. mass in below-window entries
        Strue = (torch.exp((torch.where(valid, x, ystar.expand_as(x)) - ystar)) * valid).sum(-1)
        err = (a - ref).abs() * valid
        nvalid = valid.sum()
        self._acc(L, "n_entries", nvalid)
        self._acc(L, "n_rows", valid.any(-1).sum())
        self._acc(L, "below_entries", below.sum())
        self._acc(L, "above_entries", above.sum())
        self._acc(L, "rows_below", below.any(-1).sum())
        self._acc(L, "rows_above", above.any(-1).sum())
        self._acc(L, "rows_oow", (below | above).any(-1).sum())   # a row counted once, even if both
        self._acc(L, "tail_mass_sum", tail.sum())
        self._acc(L, "tail_mass_max", tail.max(), mx=True)
        self._acc(L, "rows_S_lt_smin", (Strue < args.smin).sum())
        self._acc(L, "err_sum", err.sum())
        self._acc(L, "err_max", err.max(), mx=True)
        self._acc(L, "gap_sum", (rowmax - ystar).sum())
        self._acc(L, "gap_max", (rowmax - ystar).max(), mx=True)
        return a


@contextlib.contextmanager
def patched(p):
    F.softmax = p
    torch.nn.functional.softmax = p
    try:
        yield
    finally:
        F.softmax = ORIG_SOFTMAX
        torch.nn.functional.softmax = ORIG_SOFTMAX


def forward(batch, patch=None):
    if patch is None:
        return model(**batch, output_hidden_states=True)
    patch.reset_forward()
    with patched(patch):
        return model(**batch, output_hidden_states=True)


@torch.no_grad()
def calibrate():
    ds = load_split("train", args.ncal)
    pt = SoftmaxPatch("calib:clamp")
    pt.collect_max = True
    with patched(pt):
        for batch, _ in batches(ds):
            pt.reset_forward()
            model(**batch)
    global CALIB_MEAN, LOWV, RMAXV, GAPV
    GAPV = dict(pt.gapmax)
    CALIB_MEAN = {L: v.detach() for L, v in pt.maxima_mean.items()}
    LOWV = {L: v.detach() for L, v in pt.minima.items()}
    pt2 = SoftmaxPatch("tour:clamp")
    pt2.collect_tour = True
    with patched(pt2):
        for batch, _ in batches(ds):
            pt2.reset_forward()
            model(**batch)
    RMAXV = {k: v.detach() for k, v in pt2.rmax.items()}
    return {L: v.detach() for L, v in pt.maxima.items()}


CALIB_MEAN = {}


@torch.no_grad()
def run():
    ds = load_split(args.split, args.max_examples)
    needs_calib = args.omega_calib or any(c.startswith("calib") or c.startswith("tour") for c in args.configs)
    calib = calibrate() if needs_calib else None
    results = {}
    for cfg in args.configs:
        pt = SoftmaxPatch(cfg, calib)
        correct_ex = correct_lut = total = 0
        agree = 0
        rel_l2 = np.zeros(n_layers + 1)
        max_abs = np.zeros(n_layers + 1)
        nb = 0
        t0 = time.time()
        for batch, lab in batches(ds):
            ex = forward(batch)
            lu = forward(batch, pt)
            pe, pl = ex.logits.argmax(-1), lu.logits.argmax(-1)
            correct_ex += (pe == lab).sum().item()
            correct_lut += (pl == lab).sum().item()
            agree += (pe == pl).sum().item()
            total += len(lab)
            m = batch["attention_mask"].unsqueeze(-1).to(dt)
            for l, (he, hl) in enumerate(zip(ex.hidden_states, lu.hidden_states)):
                diff = (he - hl) * m
                rel_l2[l] += (diff.norm(dim=(1, 2)) / (he * m).norm(dim=(1, 2))).mean().item()
                max_abs[l] = max(max_abs[l], diff.abs().max().item())
            nb += 1
        rel_l2 /= nb
        per_layer = {}
        for L, d in pt.stats.items():
            ne = max(d["n_entries"], 1)
            nr = max(d["n_rows"], 1)
            per_layer[L] = dict(
                frac_entries_below=d["below_entries"] / ne, frac_entries_above=d["above_entries"] / ne,
                frac_rows_below=d["rows_below"] / nr, frac_rows_above=d["rows_above"] / nr,
                frac_rows_oow=d["rows_oow"] / nr,
                tail_mass_mean=d["tail_mass_sum"] / nr, tail_mass_max=d["tail_mass_max"],
                frac_rows_S_lt_smin=d["rows_S_lt_smin"] / nr,
                softmax_mae=d["err_sum"] / ne, softmax_max_err=d["err_max"],
                gap_mean=d["gap_sum"] / nr, gap_max=d["gap_max"])
        results[cfg] = dict(acc_exact=correct_ex / total, acc_lut=correct_lut / total,
                            label_agreement=agree / total, n=total, seconds=time.time() - t0,
                            hidden_rel_l2=rel_l2.tolist(), hidden_max_abs=max_abs.tolist(),
                            per_layer=per_layer)
        print(cfg, {k: results[cfg][k] for k in ("acc_exact", "acc_lut", "label_agreement")}, flush=True)
    return results


res = run()
raw = dict(args=vars(args), results=res, torch=torch.__version__,
           gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu")
json.dump(raw, open(f"{args.out}/raw.json", "w"), indent=1)


def sci(x):
    if x == 0:
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = round(x / 10 ** e, 2)
    if m >= 10:                       # 9.999 -> 10.00 would print "10.00x10^e"
        m, e = m / 10, e + 1
    return f"${m:.2f}{{\\times}}10^{{{e}}}$"


rows = [r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
        r"\textbf{$y^*$ : domain} & \textbf{Acc.\ exact} & \textbf{Acc.\ LUT} & \textbf{agree} & "
        r"\textbf{rows out-of-window} & \textbf{max tail mass} & \textbf{softmax max err} \\", r"\midrule"]
for cfg, r in res.items():
    pl = r["per_layer"].values()
    oow = np.mean([x["frac_rows_oow"] for x in pl]) * 100
    rows.append(f"{cfg.replace('_', ' ')} & {100 * r['acc_exact']:.2f} & {100 * r['acc_lut']:.2f} & "
                f"{100 * r['label_agreement']:.2f} & {oow:.3f}\\% & {sci(max(x['tail_mass_max'] for x in pl))} & "
                f"{sci(max(x['softmax_max_err'] for x in pl))} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/domain.tex", "w").write("\n".join(rows) + "\n")

rows = [r"\begin{tabular}{@{}lcccc@{}}", r"\toprule",
        r"\textbf{config} & \textbf{layer 1} & \textbf{layer $\lceil n/2\rceil$} & \textbf{last} & \textbf{max abs (last)} \\", r"\midrule"]
for cfg, r in res.items():
    h = r["hidden_rel_l2"]
    rows.append(f"{cfg.replace('_', ' ')} & {sci(h[1])} & {sci(h[len(h) // 2])} & {sci(h[-1])} & {sci(r['hidden_max_abs'][-1])} \\\\")
rows += [r"\bottomrule", r"\end{tabular}"]
open(f"{args.out}/prop.tex", "w").write("\n".join(rows) + "\n")
print("done ->", args.out)
