#!/usr/bin/env python3
"""gap_study.py -- how far below the row maximum do the attention logits of a real model fall?
Per layer: max over (batch,row,key,head) of (rowmax - logit) on a calibration split and on the validation split, and the
fraction of validation entries / rows whose gap exceeds the calibrated gap widened by a relative margin m."""
import argparse, json, os
import torch, torch.nn.functional as F
ap = argparse.ArgumentParser()
ap.add_argument("--model", default="distilbert-base-uncased-finetuned-sst-2-english")
ap.add_argument("--ncal", type=int, default=2000)
ap.add_argument("--batch", type=int, default=32)
ap.add_argument("--maxlen", type=int, default=128)
ap.add_argument("--margins", type=float, nargs="+", default=[0.0, 0.1, 0.2, 0.5])
ap.add_argument("--out", required=True)
ap.add_argument("--selftest", action="store_true")
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
dev, dt = a.device, torch.float64
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from datasets import load_dataset
if a.selftest:
    from transformers import DistilBertConfig, DistilBertForSequenceClassification
    model = DistilBertForSequenceClassification(DistilBertConfig(vocab_size=200, dim=32, n_layers=3, n_heads=4, hidden_dim=64,
        max_position_embeddings=64, num_labels=2, attn_implementation="eager")).to(dev).to(dt).eval()
else:
    tok = AutoTokenizer.from_pretrained(a.model)
    model = AutoModelForSequenceClassification.from_pretrained(a.model, attn_implementation="eager").to(dev).to(dt).eval()
nl = getattr(model.config, "num_hidden_layers", None) or model.config.n_layers

def data(split, n):
    if a.selftest:
        g = torch.Generator().manual_seed(1 if split == "train" else 2)
        for _ in range(0, n or 64, a.batch):
            T = 20; ids = torch.randint(1, 200, (8, T), generator=g); am = torch.ones(8, T, dtype=torch.long); am[:, 14:] = 0
            yield {"input_ids": ids.to(dev), "attention_mask": am.to(dev)}
        return
    try: ds = load_dataset("nyu-mll/glue", "sst2", split=split)
    except Exception: ds = load_dataset("glue", "sst2", split=split)
    if n: ds = ds.select(range(min(n, len(ds))))
    for i in range(0, len(ds), a.batch):
        enc = tok(ds[i:i + a.batch]["sentence"], padding=True, truncation=True, max_length=a.maxlen, return_tensors="pt")
        yield {k: v.to(dev) for k, v in enc.items()}

ORIG = F.softmax
st = {"layer": 0, "rec": None, "ref": None}
def patched(x, dim=-1, _stacklevel=3, dtype=None):
    if x.dim() != 4 or dim not in (-1, 3): return ORIG(x, dim=dim, dtype=dtype)
    L = st["layer"] % nl; st["layer"] += 1
    valid = x > -1e4
    rm = x.masked_fill(~valid, float("-inf")).amax(-1, keepdim=True)
    gap = (rm - x).masked_fill(~valid, 0.0)
    if st["ref"] is None:
        st["rec"][L] = max(st["rec"].get(L, 0.0), gap.max().item())
    else:
        r = st["ref"][L]
        for m in a.margins:
            ex = valid & (gap > r * (1 + m))
            c = st["cnt"].setdefault((L, m), [0, 0])
            c[0] += ex.sum().item(); c[1] += ex.any(-1).sum().item()
        st["cnt"].setdefault((L, "tot"), [0, 0])
        st["cnt"][(L, "tot")][0] += valid.sum().item(); st["cnt"][(L, "tot")][1] += valid.any(-1).sum().item()
        st["rec"][L] = max(st["rec"].get(L, 0.0), gap.max().item())
    return ORIG(x, dim=-1)

def run(split, n, ref=None):
    st["rec"] = {}; st["ref"] = ref; st["cnt"] = {}
    F.softmax = patched; torch.nn.functional.softmax = patched
    try:
        with torch.no_grad():
            for b in data(split, n):
                st["layer"] = 0; model(**b)
    finally:
        F.softmax = ORIG; torch.nn.functional.softmax = ORIG
    return dict(st["rec"]), dict(st["cnt"])
cal, _ = run("train", a.ncal)
val, cnt = run("validation", 0, ref=cal)
rows = {}
print("layer  cal_max_gap  val_max_gap  " + "  ".join(f"ent>cal*(1+{m})" for m in a.margins))
for L in range(nl):
    tot = cnt[(L, "tot")]
    fr = {m: (cnt[(L, m)][0] / tot[0], cnt[(L, m)][1] / tot[1]) for m in a.margins}
    rows[L + 1] = dict(cal_max=cal[L], val_max=val[L], frac_entries={str(m): fr[m][0] for m in a.margins}, frac_rows={str(m): fr[m][1] for m in a.margins})
    print(f"{L+1:5d}  {cal[L]:11.3f}  {val[L]:11.3f}  " + "  ".join(f"{fr[m][0]:.2e}/{fr[m][1]:.2e}" for m in a.margins))
json.dump(dict(model=a.model, layers=rows), open(f"{a.out}/gap_study.json", "w"), indent=1)
