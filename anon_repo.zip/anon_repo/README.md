# Artifact: single-ring CKKS encoder layer with in-loop functional bootstrapping

Code, raw logs and generated tables/figures of the paper. Everything is anonymous; third-party code is not included
(sec-CKKS, a fork of OpenFHE 1.2.3, BSD-2: https://github.com/jdumezy/sec-ckks).

## Layout
| Path | Content |
|---|---|
| `code/fhe/` | C++ harness on sec-CKKS: `bench_softmax.cpp` (modes `selftest, calibrate, curve, stage, e2e, cheb, attn, layer, boot, keys, linear`), `layer_mode.inc` (complete encoder layer, `--ops fbt|oracle`, `--maxmode tour|static`), `ctx_setup_user.cpp` (the single place that builds the context) |
| `code/emu/` | plaintext emulation of the interpolation models, analytic bounds, stage errors (`stage_errors.py`) |
| `code/model_study/` | pretrained-model study: `model_study.py` (accuracy, windows, tournament), `gap_study.py` (logit-to-row-maximum gaps), `range_study.py` (GELU / LayerNorm ranges) |
| `code/run_all.sh`, `code/go.sh` | build and run steps (`calib`, `core`, `layer`, `rest`); `go.sh` is resumable |
| `code/make_tables.py`, `code/make_paper_tables.py`, `code/make_figures.py` | generate the tables / figures from the raw logs |
| `results/raw/` | raw JSON-lines logs of the encrypted runs (context dump, thread count, CPU model in every record) |
| `results/*.tex`, `results/figs/` | the tables and figures used in the paper |
| `results/logs/` | console logs of the orchestration (`go.log`, `go3.log`) |

## Reproducing the tables and figures from the raw logs (seconds, CPU)
```
cd code
python3 emu/stage_errors.py --out ../results                       # analytic_bounds.tex, emu_stage.tex, emu_e2e.tex
python3 make_tables.py --raw ../results/raw/raw_fhe_t48_calib.jsonl ../results/raw/raw_fhe_t48_core.jsonl \
        ../results/raw/raw_fhe_t48_layer.jsonl ../results/raw/raw_fhe_t48_rest.jsonl --out ../results    # fhe_curve.tex, ...
python3 make_paper_tables.py --raw ../results/raw --out ../results  # fhe_layer*.tex, fhe_calibration.tex (run after make_tables.py)
python3 make_figures.py --raw ../results/raw --tables ../results --out ../results/figs
```
`make_tables.py` also writes tables for modes that are not part of the paper; those are empty when the corresponding mode was not run.

## Encrypted runs (CPU; sec-CKKS has no GPU path)
Needs a machine with >= 176 GB of memory for N = 2^17. Build sec-CKKS, then
`OPENFHE_DIR=/path/to/sec-ckks/install/lib/OpenFHE THREADS=48 ./code/go.sh` (steps `calib layer core rest`, markers
`done_<step>`; one process per configuration, because every FBT call leaves resident memory in the process).
The encrypted runs reported in the paper are `calib`, the curve measurement of `core`, the layer runs (`layer`: oracle, real FBT with
FBT Softmax, real FBT with leveled Softmax, n = 4 and 8) and the identity bootstrap of `rest`.
The other modes terminated by running out of memory in the reported session and are not used in the paper.

## Pretrained-model study (GPU, float64)
`pip install torch transformers datasets`; models `distilbert-base-uncased-finetuned-sst-2-english` and `textattack/bert-base-uncased-SST-2`.
```
python3 model_study/model_study.py --model <model> --dtype float64 --delta 1.5 --configs rowmax:clamp tour:clamp tour:wrap --out <dir>
python3 model_study/model_study.py --model <model> --dtype float64 --delta 1.5 --omega <W> --configs tour:wrap --out <dir>              # fixed windows
python3 model_study/model_study.py --model <model> --dtype float64 --delta 1.5 --omega_calib --omega_margin <mu> --configs tour:wrap --out <dir>
python3 model_study/gap_study.py   --model <model> --out <dir>
python3 model_study/range_study.py --out <dir> --margin 0.2 --p 256 --guard 8
```
`results/tour_emu.tex` and `results/gap_study.tex` collect the printed results of these commands for both models.
Smoke tests without network: `--selftest`.
